// ============================================
// LD Framework: Discrete Scale Invariance
// Data from paper_v5
// ============================================

// Fundamental constants
export const CONSTANTS = {
  me: 0.51099895, // MeV - electron mass
  mu: 1836.15267343, // m_p/m_e
  alpha: 1/137.035999084, // fine structure constant
  alpha_inv: 137.035999084,
  G: 6.6741e-11, // m³/(kg·s²)
  pi: Math.PI,
};

export const g = CONSTANTS.mu ** (1/4);
export const alpha_2pi = CONSTANTS.alpha / (2 * Math.PI);

// Lenz formula: mu_0 = 6*pi^5
export const mu_0 = 6 * Math.PI ** 5;
export const mu_0_error = Math.abs(CONSTANTS.mu - mu_0) / CONSTANTS.mu;

// ============================================
// Particle mass spectrum data (Table 1)
// ============================================
export const particlesData = [
  { name: 'e', n: 0, K: 1, m_exp: 0.5110, m_pred: 0.5110, anchor: true, type: 'lepton' as const },
  { name: 'u', n: 1, K: 2/3, m_exp: 2.16, m_pred: 2.230, anchor: false, type: 'quark' as const },
  { name: 'd', n: 1, K: Math.sqrt(2), m_exp: 4.67, m_pred: 4.731, anchor: false, type: 'quark' as const },
  { name: 'μ', n: 3, K: 3/4, m_exp: 105.658, m_pred: 107.5, anchor: false, type: 'lepton' as const },
  { name: 's', n: 3, K: 2/3, m_exp: 93.4, m_pred: 95.56, anchor: false, type: 'quark' as const },
  { name: 'p', n: 4, K: 1, m_exp: 938.27, m_pred: 938.27, anchor: true, type: 'anchor' as const },
  { name: 'c', n: 4, K: 4/3, m_exp: 1270, m_pred: 1251.0, anchor: false, type: 'quark' as const },
  { name: 'τ', n: 4, K: 2, m_exp: 1776.86, m_pred: 1876.5, anchor: false, type: 'lepton' as const },
  { name: 'b', n: 5, K: 2/3, m_exp: 4180, m_pred: 4094.6, anchor: false, type: 'quark' as const },
  { name: 'W', n: 6, K: 2, m_exp: 80377, m_pred: 80411, anchor: false, type: 'boson' as const },
  { name: 'H', n: 6, K: 3, m_exp: 125100, m_pred: 120616, anchor: false, type: 'boson' as const },
  { name: 't', n: 7, K: 2/3, m_exp: 172690, m_pred: 175456, anchor: false, type: 'quark' as const },
];

// Calculate deltaK for each particle
export const particlesWithDeltaK = particlesData.map(p => ({
  ...p,
  deltaK: ((p.m_exp - p.m_pred) / p.m_pred) * 100
}));

// ============================================
// DeltaK residuals (Table 2)
// ============================================
export const deltaKTable = [
  { name: 'u', pred: -2.34, obs: -3.14, n: 1, ell: 3, phi: 0.86, ew: -21.0 },
  { name: 'd', pred: -2.34, obs: -1.28, n: 1, ell: 3, phi: 0.86, ew: -21.0 },
  { name: 'μ', pred: -3.90, obs: -1.71, n: 3, ell: 7, phi: 15.43, ew: -49.0 },
  { name: 's', pred: -0.65, obs: -2.26, n: 3, ell: 3, phi: 15.43, ew: -21.0 },
  { name: 'c', pred: +0.75, obs: +1.52, n: 4, ell: 3, phi: 27.43, ew: -21.0 },
  { name: 'τ', pred: -2.51, obs: -5.31, n: 4, ell: 7, phi: 27.43, ew: -49.0 },
  { name: 'b', pred: +1.71, obs: +2.09, n: 5, ell: 3, phi: 35.71, ew: -21.0 },
  { name: 'W', pred: -1.29, obs: -0.04, n: 6, ell: 6, phi: 30.86, ew: -42.0 },
  { name: 'H', pred: +2.77, obs: +3.72, n: 6, ell: 1, phi: 30.86, ew: -7.0 },
  { name: 't', pred: -2.44, obs: -1.58, n: 7, ell: 3, phi: 0.00, ew: -21.0 },
];

// ============================================
// B1 Set (10 elements with Tree Complexity)
// ============================================
export const B1Set: Array<{value: number, label: string, tc: number, formula: string}> = [
  { value: 1/3, label: '1/3', tc: 1, formula: '1÷3' },
  { value: 1/2, label: '1/2', tc: 1, formula: '1÷2' },
  { value: 2/3, label: '2/3', tc: 1, formula: '2÷3' },
  { value: 3/4, label: '3/4', tc: 2, formula: '3÷4' },
  { value: 1, label: '1', tc: 0, formula: '1' },
  { value: 4/3, label: '4/3', tc: 2, formula: '4÷3' },
  { value: Math.sqrt(2), label: '√2', tc: 1, formula: '√2' },
  { value: 3/2, label: '3/2', tc: 2, formula: '3÷2' },
  { value: 2, label: '2', tc: 1, formula: '2' },
  { value: 3, label: '3', tc: 1, formula: '3' },
];

// ============================================
// Modular properties of Γ₀(6)
// ============================================
export const modularProperties = [
  { key: 'Level N', value: 6 },
  { key: 'Index [Γ:Γ₀(6)]', value: 12 },
  { key: 'Number of cusps', value: 4 },
  { key: 'Cusp widths', value: [1, 2, 3, 6] },
  { key: 'Genus g', value: 0 },
  { key: 'ν₂ (elliptic)', value: 0 },
  { key: 'ν₃ (elliptic)', value: 0 },
  { key: 'Dessin edges', value: 12 },
  { key: 'Black vertices (d₂=3)', value: 4 },
  { key: 'White vertices (d₁=2)', value: 6 },
  { key: 'Face sizes', value: [6, 3, 2, 1] },
  { key: 'Monodromy group', value: 'PSL₂(ℤ/6ℤ)' },
  { key: 'Group order', value: 72 },
  { key: 'Kirchhoff number K', value: 40 },
];

// BBT Eigenvalues
export const BBT_eigenvalues = [6, 5, 2, 1];
export const kirchhoffNumber = 40;

// Biadjacency matrix B (4×6)
export const biadjacencyMatrix = [
  [2, 1, 0, 0, 0, 0],
  [0, 1, 1, 0, 1, 0],
  [0, 0, 1, 1, 0, 1],
  [0, 0, 0, 1, 1, 1],
];

// BBT matrix
export const BBTMatrix = [
  [5, 1, 0, 0],
  [1, 3, 1, 1],
  [0, 1, 3, 2],
  [0, 1, 2, 3],
];

// ============================================
// Dessin d'Enfant structure
// ============================================
export const dessinEdges = [
  { id: 0, name: 'e', blackVertex: 0, whiteVertex: 0, faceSize: 1, type: 'anchor' as const },
  { id: 1, name: 'u', blackVertex: 1, whiteVertex: 0, faceSize: 6, type: 'quark' as const },
  { id: 2, name: 'd', blackVertex: 1, whiteVertex: 1, faceSize: 6, type: 'quark' as const },
  { id: 3, name: 'μ', blackVertex: 2, whiteVertex: 1, faceSize: 3, type: 'lepton' as const },
  { id: 4, name: 's', blackVertex: 2, whiteVertex: 2, faceSize: 6, type: 'quark' as const },
  { id: 5, name: 'p', blackVertex: 2, whiteVertex: 3, faceSize: 1, type: 'anchor' as const },
  { id: 6, name: 'c', blackVertex: 3, whiteVertex: 2, faceSize: 6, type: 'quark' as const },
  { id: 7, name: 'τ', blackVertex: 3, whiteVertex: 3, faceSize: 3, type: 'lepton' as const },
  { id: 8, name: 'b', blackVertex: 3, whiteVertex: 4, faceSize: 6, type: 'quark' as const },
  { id: 9, name: 'W', blackVertex: 0, whiteVertex: 4, faceSize: 2, type: 'boson' as const },
  { id: 10, name: 'H', blackVertex: 0, whiteVertex: 5, faceSize: 2, type: 'boson' as const },
  { id: 11, name: 't', blackVertex: 1, whiteVertex: 5, faceSize: 6, type: 'quark' as const },
];

export const dessinBlackVertices = [
  { id: 0, valency: 3, x: 0, y: 0 },
  { id: 1, valency: 3, x: 3, y: 0 },
  { id: 2, valency: 3, x: 6, y: 0 },
  { id: 3, valency: 3, x: 9, y: 0 },
];

export const dessinWhiteVertices = [
  { id: 0, valency: 2, x: 1.5, y: 2 },
  { id: 1, valency: 2, x: 4.5, y: 2 },
  { id: 2, valency: 2, x: 7.5, y: 2 },
  { id: 3, valency: 2, x: 1.5, y: -2 },
  { id: 4, valency: 2, x: 4.5, y: -2 },
  { id: 5, valency: 2, x: 7.5, y: -2 },
];

// ============================================
// CKM Parameters (Wolfenstein)
// ============================================
export const ckmPredictions = [
  { name: 'λ', pred: 9/40, exp: 0.22497, exp_err: 0.00070, formula: 'd₂²/K = 9/40' },
  { name: 'A', pred: 3/Math.sqrt(13), exp: 0.839, exp_err: 0.011, formula: 'd₂/√(d₁²+d₂²)' },
  { name: 'γ', pred: Math.atan(9/4) * 180 / Math.PI, exp: 65.98, exp_err: 4.0, formula: 'arctan(d₂²/d₁²)' },
  { name: 'R_b²', pred: 3/20, exp: 0.15088, exp_err: 0.007, formula: 'N/K = 6/40 = 3/20' },
];

// ============================================
// Neutrino predictions
// ============================================
export const neutrinos = [
  { name: 'ν₁', n: -9, K: 1/3, m_pred: 7.72 },
  { name: 'ν₂', n: -9, K: 1/2, m_pred: 11.58 },
  { name: 'ν₃', n: -8, K: 1/3, m_pred: 50.52 },
];

export const sum_m_nu = neutrinos.reduce((sum, n) => sum + n.m_pred, 0);
export const dm2_21 = 7.446e-5;
export const dm2_31 = 2.493e-3;

// PMNS sin²θ₁₂
export const sin2theta12_pred = 4/13;
export const sin2theta12_exp = 0.3092;
export const sin2theta12_err = 0.0087;
export const pull_juno = (sin2theta12_pred - sin2theta12_exp) / sin2theta12_err;

// ============================================
// Alpha formula components
// ============================================
export const alphaFormula = {
  bulk: (432/Math.PI) * Math.cos(1/(6*Math.PI))**2,
  ir: (Math.PI/36) * (1 - 1/1728 + 11/1728**2),
  predicted: 137.035999084,
  experimental: 137.035999084,
};

// ============================================
// Laplacian eigenvalues (Cayley graph)
// ============================================
export const laplacianEigenvalues = [
  0, 1, 3, 3, 4, 5, 5, 5,
  (5 + Math.sqrt(21)) / 2,
  (5 - Math.sqrt(21)) / 2,
  (5 + Math.sqrt(5)) / 2,
  (5 - Math.sqrt(5)) / 2
];

// ============================================
// G formula
// ============================================
export const GFormula = {
  predicted: 6.6741e-11,
  codata2018: 6.67430e-11,
  codata2014: 6.67408e-11,
  deviation2018: -35, // ppm
  deviation2014: 3, // ppm
};

// ============================================
// Falsification map predictions
// ============================================
export const falsificationPredictions: {
  numerical: Array<{ name: string; experiment: string; year: number; status: string }>;
  structural: Array<{ name: string; experiment: string; year: number; status: string }>;
} = {
  numerical: [
    { name: 'sin²θ₁₂ = 4/13', experiment: 'JUNO', year: 2027, status: '✅ +0.17σ' },
    { name: 'κ_τ = 1.056', experiment: 'HL-LHC', year: 2028, status: '⏳ Ожидается' },
    { name: 'Σm_ν = 69.8 meV', experiment: 'DESI/Euclid', year: 2027, status: '⏳ Совместимо' },
    { name: 'm_d/m_u = 3√2/2', experiment: 'FLAG', year: 2026, status: '⏳ ±1.3σ' },
    { name: 'G = 6.6741×10⁻¹¹', experiment: 'CODATA', year: 2026, status: '⏳ -35 ppm' },
    { name: 'α⁻¹ (0.001 ppb)', experiment: 'Rb/Cs', year: 2026, status: '⏳ Rb-Cs tension' },
    { name: '⟨m_ββ⟩ = 0.6-9.8 meV', experiment: 'LEGEND/nEXO', year: 2028, status: '⏳ Ожидается' },
  ],
  structural: [
    { name: 'Normal ordering ν', experiment: 'JUNO/DUNE', year: 2027, status: '⏳ Совместимо' },
    { name: 'Proton stable', experiment: 'Hyper-K', year: 2030, status: '✅ τ > 10³⁴ yr' },
    { name: '1 Higgs doublet', experiment: 'HL-LHC', year: 2028, status: '✅ Пока да' },
    { name: 'Desert at n=2', experiment: 'Resonance search', year: 2027, status: '✅ No particles' },
    { name: 'No elementary DM', experiment: 'HL-LHC', year: 2028, status: '✅ Пока нет' },
    { name: 'G = f(α, μ, m_e)', experiment: 'G refinement', year: 2027, status: '⏳ Within error' },
  ]
};

// ============================================
// Test results
// ============================================
export type TestStatus = 'passed' | 'pending' | 'failed';

export const allTests: Array<{ test: string; result: string; status: TestStatus; reference?: string }> = [
  { test: 'Particle masses (RMS)', result: '1.45%', status: 'passed', reference: '§2' },
  { test: 'Signs δK (10/10)', result: '10/10', status: 'passed', reference: '§6' },
  { test: 'BBT spectrum', result: '[6,5,2,1]', status: 'passed', reference: 'Thm 4.15' },
  { test: 'Kirchhoff number K', result: '40', status: 'passed', reference: 'Thm 4.16' },
  { test: 'sin²θ₁₂ (JUNO)', result: '+0.17σ', status: 'passed', reference: '§8' },
  { test: 'Fine structure α', result: '+0.001 ppb', status: 'passed', reference: '§5' },
  { test: 'Gravitational G', result: '-35 ppm', status: 'passed', reference: '§7' },
  { test: 'Proton-electron μ', result: '<0.001 ppm', status: 'passed', reference: '§5' },
  { test: 'Heat kernel', result: '4.6 ppm', status: 'passed', reference: 'Obs 8.4' },
  { test: 'Quark sub-ladder', result: '±2%', status: 'passed', reference: '§2.5' },
  { test: 'Hierarchy M_Pl/m_e', result: '0.06 orders', status: 'passed', reference: '§7' },
  { test: 'Neutrino Σm_ν', result: '69.8 meV', status: 'pending', reference: '§8' },
  { test: 'Neutrino Δm²₂₁', result: '+0.20σ', status: 'passed', reference: '§8' },
  { test: 'Neutrino Δm²₃₁', result: '-0.32σ', status: 'passed', reference: '§8' },
];

// ============================================
// Derivation status table
// ============================================
export const derivationStatus: Array<{ result: string; status: 'theorem' | 'derived' | 'observational' | 'conjecture' | 'fitted' | 'gap'; reference: string }> = [
  { result: '12 particles = index', status: 'theorem', reference: '§4.5' },
  { result: 'Dessin uniqueness (36/36)', status: 'theorem', reference: 'Thm 4.10' },
  { result: 'σ²(B) = {6,5,2,1}', status: 'theorem', reference: 'Thm 4.15' },
  { result: 'Kirchhoff K = 40', status: 'theorem', reference: 'Thm 4.16' },
  { result: 'Residual Tree (λ = 9/40)', status: 'theorem', reference: 'Thm 4.17' },
  { result: 'CKM Wolfenstein 4/4', status: 'observational', reference: '§4.7' },
  { result: 'B₁ from MDL + ⟨2,3⟩', status: 'derived', reference: '§3' },
  { result: '(n,K)-uniqueness', status: 'theorem', reference: 'Thm 3.5' },
  { result: 'n-formulas (quarks 6/6, leptons 3/3)', status: 'theorem', reference: 'Thm 6.5-6.6' },
  { result: 'Isospin Theorem', status: 'theorem', reference: 'Thm 6.7' },
  { result: 'ℓ from dessin (12/12)', status: 'derived', reference: 'Prop 6.8' },
  { result: 'α BULK (~600ppm)', status: 'derived', reference: '§5.5' },
  { result: 'α IR (0.001ppb)', status: 'fitted', reference: 'Rem 5.2' },
  { result: 'μ = 6π⁵; cₙ from Riemann-Roch', status: 'theorem', reference: 'Thm 5.1' },
  { result: 'Φ exponents from ramification', status: 'theorem', reference: 'Thm 4.8' },
  { result: 'BCs from well-posedness', status: 'theorem', reference: 'Thm 6.2' },
  { result: 'α/(2π) from 4D Weyl', status: 'theorem', reference: 'Thm 6.4' },
  { result: 'G as ring closure', status: 'derived', reference: '§7' },
  { result: 'sin²θ₁₂ = 4/13', status: 'conjecture', reference: 'Conj 8.1' },
  { result: 'Heat kernel |U₀|² = 4/13', status: 'observational', reference: 'Obs 8.4' },
];

// ============================================
// Calculate statistics
// ============================================
export const nonAnchorParticles = particlesWithDeltaK.filter(p => !p.anchor);
export const rms = Math.sqrt(nonAnchorParticles.reduce((sum, p) => sum + (p.deltaK || 0) ** 2, 0) / nonAnchorParticles.length);
export const maxDeltaK = Math.max(...nonAnchorParticles.map(p => Math.abs(p.deltaK || 0)));

// P-value calculation
export const delta_log = Math.log(Math.max(...particlesWithDeltaK.map(p => p.m_exp)) / Math.min(...particlesWithDeltaK.map(p => p.m_exp)));
export const pValues = nonAnchorParticles.map(p => 2 * Math.abs((p.deltaK || 0) / 100) / delta_log);
export const pJoint = pValues.reduce((prod, p) => prod * p, 1);

// Sign match calculation
export const signsMatch = deltaKTable.filter(d => Math.sign(d.pred) === Math.sign(d.obs)).length;
