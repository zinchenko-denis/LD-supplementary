import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { DashboardSection } from '@/sections/DashboardSection';
import { ConstantsSection } from '@/sections/ConstantsSection';
import { DessinSection } from '@/sections/DessinSection';
import { B1SetSection } from '@/sections/B1SetSection';
import { MassSpectrumSection } from '@/sections/MassSpectrumSection';
import { DeltaKSection } from '@/sections/DeltaKSection';
import { CKMSection } from '@/sections/CKMSection';
import { AlphaSection } from '@/sections/AlphaSection';
import { NeutrinoSection } from '@/sections/NeutrinoSection';
import { GravitySection } from '@/sections/GravitySection';
import { FalsificationSection } from '@/sections/FalsificationSection';
import { DerivationSection } from '@/sections/DerivationSection';
import { 
  LayoutDashboard, 
  Calculator, 
  GitGraph, 
  Grid3X3, 
  Atom, 
  BarChart3, 
  Target, 
  Waves,
  Globe,
  Map,
  FileCheck,
  ExternalLink
} from 'lucide-react';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-3">
              <GitGraph className="w-8 h-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold text-slate-900">
                  LD Framework
                </h1>
                <p className="text-sm text-slate-500">
                  Discrete Scale Invariance from Modular Geometry
                </p>
              </div>
            </div>
            <a 
              href="https://doi.org/10.5281/zenodo.19046582"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-4 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg transition-colors"
            >
              <ExternalLink className="w-4 h-4" />
              <span className="text-sm font-medium">DOI: 10.5281/zenodo.19046582</span>
            </a>
          </div>
          <div className="mt-3 text-xs text-slate-400 flex items-center gap-4 flex-wrap">
            <span>Author: Denis D. Zinchenko (Independent Researcher)</span>
            <span>•</span>
            <span>March 2026</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <Card className="sticky top-4 z-50 shadow-lg">
            <CardContent className="p-2">
              <TabsList className="w-full flex flex-wrap justify-start gap-1 h-auto">
                <TabsTrigger value="dashboard" className="flex items-center gap-1 px-3 py-2">
                  <LayoutDashboard className="w-4 h-4" />
                  <span className="hidden sm:inline">Dashboard</span>
                </TabsTrigger>
                <TabsTrigger value="constants" className="flex items-center gap-1 px-3 py-2">
                  <Calculator className="w-4 h-4" />
                  <span className="hidden sm:inline">Constants</span>
                </TabsTrigger>
                <TabsTrigger value="dessin" className="flex items-center gap-1 px-3 py-2">
                  <GitGraph className="w-4 h-4" />
                  <span className="hidden sm:inline">Dessin</span>
                </TabsTrigger>
                <TabsTrigger value="b1" className="flex items-center gap-1 px-3 py-2">
                  <Grid3X3 className="w-4 h-4" />
                  <span className="hidden sm:inline">B₁ Set</span>
                </TabsTrigger>
                <TabsTrigger value="masses" className="flex items-center gap-1 px-3 py-2">
                  <Atom className="w-4 h-4" />
                  <span className="hidden sm:inline">Masses</span>
                </TabsTrigger>
                <TabsTrigger value="deltak" className="flex items-center gap-1 px-3 py-2">
                  <BarChart3 className="w-4 h-4" />
                  <span className="hidden sm:inline">δK</span>
                </TabsTrigger>
                <TabsTrigger value="ckm" className="flex items-center gap-1 px-3 py-2">
                  <Target className="w-4 h-4" />
                  <span className="hidden sm:inline">CKM</span>
                </TabsTrigger>
                <TabsTrigger value="alpha" className="flex items-center gap-1 px-3 py-2">
                  <Waves className="w-4 h-4" />
                  <span className="hidden sm:inline">α</span>
                </TabsTrigger>
                <TabsTrigger value="neutrino" className="flex items-center gap-1 px-3 py-2">
                  <Atom className="w-4 h-4" />
                  <span className="hidden sm:inline">ν</span>
                </TabsTrigger>
                <TabsTrigger value="gravity" className="flex items-center gap-1 px-3 py-2">
                  <Globe className="w-4 h-4" />
                  <span className="hidden sm:inline">G</span>
                </TabsTrigger>
                <TabsTrigger value="falsification" className="flex items-center gap-1 px-3 py-2">
                  <Map className="w-4 h-4" />
                  <span className="hidden sm:inline">Tests</span>
                </TabsTrigger>
                <TabsTrigger value="derivation" className="flex items-center gap-1 px-3 py-2">
                  <FileCheck className="w-4 h-4" />
                  <span className="hidden sm:inline">Status</span>
                </TabsTrigger>
              </TabsList>
            </CardContent>
          </Card>

          <TabsContent value="dashboard" className="mt-0">
            <DashboardSection />
          </TabsContent>

          <TabsContent value="constants" className="mt-0">
            <ConstantsSection />
          </TabsContent>

          <TabsContent value="dessin" className="mt-0">
            <DessinSection />
          </TabsContent>

          <TabsContent value="b1" className="mt-0">
            <B1SetSection />
          </TabsContent>

          <TabsContent value="masses" className="mt-0">
            <MassSpectrumSection />
          </TabsContent>

          <TabsContent value="deltak" className="mt-0">
            <DeltaKSection />
          </TabsContent>

          <TabsContent value="ckm" className="mt-0">
            <CKMSection />
          </TabsContent>

          <TabsContent value="alpha" className="mt-0">
            <AlphaSection />
          </TabsContent>

          <TabsContent value="neutrino" className="mt-0">
            <NeutrinoSection />
          </TabsContent>

          <TabsContent value="gravity" className="mt-0">
            <GravitySection />
          </TabsContent>

          <TabsContent value="falsification" className="mt-0">
            <FalsificationSection />
          </TabsContent>

          <TabsContent value="derivation" className="mt-0">
            <DerivationSection />
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-12">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="text-center text-sm text-slate-500 space-y-2">
            <p>LD Framework: Discrete Scale Invariance from Modular Geometry</p>
            <p>
              <a 
                href="https://doi.org/10.5281/zenodo.19046582"
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline"
              >
                DOI: 10.5281/zenodo.19046582
              </a>
            </p>
            <p className="text-xs">Interactive visualization of numerical predictions</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
