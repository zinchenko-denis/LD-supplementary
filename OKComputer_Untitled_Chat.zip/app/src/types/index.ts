export interface Particle {
  name: string;
  n: number;
  K: number;
  m_exp: number;
  m_pred: number;
  anchor: boolean;
  deltaK?: number;
  type: 'quark' | 'lepton' | 'boson' | 'anchor';
  edgeId?: number;
}

export interface DeltaKEntry {
  name: string;
  pred: number;
  obs: number;
  n: number;
  ell: number;
  phi: number;
  ew: number;
}

export interface CKMParameter {
  name: string;
  pred: number;
  exp: number;
  exp_err: number;
  pull?: number;
  formula: string;
}

export interface Neutrino {
  name: string;
  n: number;
  K: number;
  m_pred: number;
}

export interface Prediction {
  name: string;
  experiment: string;
  year: number;
  status: string;
  category: 'numerical' | 'structural';
}

export interface TestResult {
  test: string;
  result: string;
  status: 'passed' | 'pending' | 'failed';
  reference?: string;
}

export interface ModularProperty {
  key: string;
  value: string | number | number[];
}

export interface DessinEdge {
  id: number;
  name: string;
  blackVertex: number;
  whiteVertex: number;
  faceSize: number;
  type: 'quark' | 'lepton' | 'boson' | 'anchor';
}

export interface DessinVertex {
  id: number;
  type: 'black' | 'white';
  valency: number;
  x: number;
  y: number;
}

export interface B1Element {
  value: number;
  label: string;
  tc: number;
  formula: string;
}

export interface DerivationStatus {
  result: string;
  status: 'theorem' | 'derived' | 'observational' | 'conjecture' | 'fitted' | 'gap';
  reference: string;
}
