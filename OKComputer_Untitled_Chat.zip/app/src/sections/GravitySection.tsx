import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { GFormula } from '@/data/modelData';

export function GravitySection() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Gravitational Constant G</h2>
        <Badge variant="outline">§7</Badge>
      </div>

      {/* Ring Closure */}
      <Card className="bg-gradient-to-r from-orange-50 to-red-50">
        <CardHeader>
          <CardTitle>G as Ring-Closure Condition</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-xl font-mono mb-6">
            G = (e²/ε₀) · mₑ⁻² · α^(-2q) = (α²/μ) · mₑ⁻² · α^(-2q)
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-white rounded-lg">
              <div className="text-sm text-gray-500">LO q</div>
              <div className="text-2xl font-mono">(index · Πwᵢ)²/(N·π^(N+1))</div>
              <div className="text-lg font-bold text-blue-600">= 432²/(6π⁷)</div>
              <div className="text-lg">= 10.298</div>
              <div className="text-xs text-gray-400">δ = 0.67%</div>
            </div>
            
            <div className="text-center p-4 bg-white rounded-lg">
              <div className="text-sm text-gray-500">Predicted G</div>
              <div className="text-3xl font-bold text-green-600">{GFormula.predicted.toExponential(4)}</div>
              <div className="text-sm">m³/(kg·s²)</div>
            </div>
            
            <div className="text-center p-4 bg-white rounded-lg">
              <div className="text-sm text-gray-500">Deviations</div>
              <div className="text-lg">
                <span className="text-orange-600">{GFormula.deviation2018} ppm</span> (2018)
              </div>
              <div className="text-lg">
                <span className="text-green-600">+{GFormula.deviation2014} ppm</span> (2014)
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Hierarchy Formula */}
      <Card>
        <CardHeader>
          <CardTitle>The Hierarchy Formula</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-2xl font-mono mb-4">
            M_Pl/mₑ = α^(-q/4πα)
          </div>
          <div className="text-center text-lg text-gray-600 mb-6">
            The exponential arises because α² · μ ≈ 0.098 ≪ 1
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-3 bg-slate-50 rounded-lg">
              <div className="text-sm text-gray-500">M_Pl</div>
              <div className="text-lg font-mono">~10¹⁹ GeV</div>
            </div>
            <div className="text-center p-3 bg-slate-50 rounded-lg">
              <div className="text-sm text-gray-500">mₑ</div>
              <div className="text-lg font-mono">0.511 MeV</div>
            </div>
            <div className="text-center p-3 bg-slate-50 rounded-lg">
              <div className="text-sm text-gray-500">Ratio</div>
              <div className="text-lg font-mono">~10²²</div>
            </div>
            <div className="text-center p-3 bg-green-100 rounded-lg">
              <div className="text-sm text-gray-500">From geometry</div>
              <div className="text-lg font-bold text-green-600">✓</div>
            </div>
          </div>
          
          <div className="mt-4 text-center text-sm text-gray-600">
            One geometry → one scale → no independent hierarchy
          </div>
        </CardContent>
      </Card>

      {/* √2 Knockout */}
      <Card className="bg-red-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Badge className="bg-red-600">√2 Knockout</Badge>
            Sensitivity Test
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-4 bg-white rounded-lg">
              <div className="text-sm text-gray-500">Remove √2 from B₁</div>
              <div className="text-lg font-mono mt-2">δμ = -1.88 ppm</div>
            </div>
            <div className="text-center p-4 bg-white rounded-lg">
              <div className="text-sm text-gray-500">Amplification</div>
              <div className="text-lg font-mono mt-2">100.7×</div>
            </div>
            <div className="text-center p-4 bg-red-100 rounded-lg">
              <div className="text-sm text-gray-500">Result</div>
              <div className="text-2xl font-bold text-red-600 mt-2">δG = -189 ppm</div>
              <div className="text-sm text-red-600">8.4σ deviation</div>
            </div>
          </div>
          <div className="mt-4 text-center text-sm">
            One irrational number from EWSB is necessary for ring closure.
          </div>
        </CardContent>
      </Card>

      {/* Comparison Table */}
      <Card>
        <CardHeader>
          <CardTitle>G Measurements</CardTitle>
        </CardHeader>
        <CardContent>
          <table className="w-full text-sm">
            <thead className="bg-slate-50">
              <tr>
                <th className="p-2 text-left">Source</th>
                <th className="p-2 text-left">Value (×10⁻¹¹)</th>
                <th className="p-2 text-left">Deviation from LD</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b bg-green-50">
                <td className="p-2 font-medium">LD Prediction</td>
                <td className="p-2 font-mono">{GFormula.predicted.toExponential(4)}</td>
                <td className="p-2">—</td>
              </tr>
              <tr className="border-b">
                <td className="p-2">CODATA 2018</td>
                <td className="p-2 font-mono">{GFormula.codata2018.toExponential(4)}</td>
                <td className="p-2 text-orange-600">-35 ppm</td>
              </tr>
              <tr className="border-b">
                <td className="p-2">CODATA 2014</td>
                <td className="p-2 font-mono">{GFormula.codata2014.toExponential(4)}</td>
                <td className="p-2 text-green-600">+3 ppm</td>
              </tr>
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
