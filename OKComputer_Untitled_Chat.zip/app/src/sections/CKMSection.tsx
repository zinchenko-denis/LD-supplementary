import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { ckmPredictions } from '@/data/modelData';

export function CKMSection() {
  const ckmWithPull = ckmPredictions.map(p => ({
    ...p,
    pull: (p.pred - p.exp) / p.exp_err
  }));

  const maxPull = Math.max(...ckmWithPull.map(p => Math.abs(p.pull || 0)));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">CKM Matrix from Kirchhoff Number</h2>
        <Badge variant="outline">§4.7</Badge>
      </div>

      {/* Kirchhoff Number */}
      <Card className="bg-gradient-to-r from-yellow-50 to-orange-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Badge className="bg-yellow-600">Theorem 4.16</Badge>
            Kirchhoff Number K = 40
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-white rounded-lg">
              <div className="text-sm text-gray-500">Formula</div>
              <div className="text-xl font-mono">K = |B₁| · d₁²</div>
            </div>
            <div className="text-center p-4 bg-white rounded-lg">
              <div className="text-sm text-gray-500">Calculation</div>
              <div className="text-xl font-mono">10 · 2² = 40</div>
            </div>
            <div className="text-center p-4 bg-yellow-100 rounded-lg">
              <div className="text-sm text-gray-500">Result</div>
              <div className="text-3xl font-bold text-yellow-600">40</div>
            </div>
          </div>
          <div className="mt-4 text-center text-sm text-gray-600">
            Number of spanning trees of the dessin&apos;s bipartite graph
          </div>
        </CardContent>
      </Card>

      {/* Wolfenstein Parameters */}
      <Card>
        <CardHeader>
          <CardTitle>Wolfenstein Parameters from K = 40</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Parameter</TableHead>
                <TableHead>Formula</TableHead>
                <TableHead>Prediction</TableHead>
                <TableHead>Experiment (PDG)</TableHead>
                <TableHead>Pull (σ)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {ckmWithPull.map((p) => (
                <TableRow key={p.name}>
                  <TableCell className="font-medium">{p.name}</TableCell>
                  <TableCell className="font-mono text-sm">{p.formula}</TableCell>
                  <TableCell>{p.pred.toFixed(5)}</TableCell>
                  <TableCell>{p.exp.toFixed(5)} ± {p.exp_err.toFixed(5)}</TableCell>
                  <TableCell className={Math.abs(p.pull || 0) < 1 ? 'text-green-600' : 'text-orange-500'}>
                    {(p.pull || 0) > 0 ? '+' : ''}{(p.pull || 0).toFixed(2)}σ
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <div className="mt-4 p-3 bg-green-50 rounded-lg">
            <span className="font-medium">Maximum |pull|: {maxPull.toFixed(2)}σ</span>
            <span className="text-gray-500 ml-2">| 2 inputs (d₁, d₂), 3 independent outputs</span>
          </div>
        </CardContent>
      </Card>

      {/* Residual Tree Theorem */}
      <Card className="bg-blue-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Badge className="bg-blue-600">Theorem 4.17</Badge>
            Residual Tree Theorem: λ = d₂²/K = 9/40
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <p className="text-sm">
                Each spanning tree decomposes into:
              </p>
              <ul className="list-disc list-inside text-sm space-y-1">
                <li>Forced edges {'{c,t}'} (bridges)</li>
                <li>Three competing boundary pairs</li>
                <li>Residual register</li>
              </ul>
              <div className="p-3 bg-white rounded-lg">
                <div className="text-sm text-gray-500">Valid residual completions</div>
                <div className="text-xl font-mono">d₂² = 9</div>
              </div>
            </div>
            <div className="space-y-3">
              <div className="p-3 bg-white rounded-lg text-center">
                <div className="text-sm text-gray-500">Graph identity</div>
                <div className="text-2xl font-mono">λ = d₂²/K = 9/40</div>
                <div className="text-lg text-blue-600">= 0.22500</div>
              </div>
              <div className="p-3 bg-white rounded-lg text-center">
                <div className="text-sm text-gray-500">Experimental</div>
                <div className="text-lg font-mono">0.22497 ± 0.00070</div>
                <div className="text-green-600">Pull: -0.04σ ✓</div>
              </div>
            </div>
          </div>
          <div className="mt-4 p-3 bg-yellow-100 rounded-lg text-sm">
            <span className="font-medium">Note:</span> The graph identity λ = d₂²/K is a theorem; 
            the physical identification λ = λ_Wolfenstein remains observational.
          </div>
        </CardContent>
      </Card>

      {/* Gauge Visualizations */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {ckmWithPull.map((p) => (
          <Card key={p.name}>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">{p.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Formula:</span>
                  <span className="font-mono text-sm">{p.formula}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Prediction:</span>
                  <span className="font-bold">{p.pred.toFixed(5)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Experiment:</span>
                  <span>{p.exp.toFixed(5)} ± {p.exp_err.toFixed(5)}</span>
                </div>
                
                {/* Gauge */}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span>3σ range</span>
                    <span>Pull: {(p.pull || 0).toFixed(2)}σ</span>
                  </div>
                  <div className="relative h-4 bg-gray-200 rounded-full overflow-hidden">
                    <div 
                      className="absolute h-full bg-green-200 rounded-full"
                      style={{ 
                        left: `${Math.max(0, Math.min(100, 50 - (3 * p.exp_err / p.exp) * 50))}%`,
                        width: `${Math.min(100, (6 * p.exp_err / p.exp) * 50)}%`
                      }}
                    />
                    <div 
                      className="absolute w-1 h-full bg-blue-600"
                      style={{ left: `${Math.max(0, Math.min(100, 50 + ((p.pred - p.exp) / p.exp) * 50))}%` }}
                    />
                    <div 
                      className="absolute w-0.5 h-full bg-green-700"
                      style={{ left: '50%' }}
                    />
                  </div>
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>{(p.exp - 3 * p.exp_err).toFixed(3)}</span>
                    <span className="text-green-700 font-medium">{p.exp.toFixed(3)}</span>
                    <span>{(p.exp + 3 * p.exp_err).toFixed(3)}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
