import { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';
import { dessinEdges, dessinBlackVertices, dessinWhiteVertices, modularProperties, particlesWithDeltaK, g, CONSTANTS } from '@/data/modelData';
import { Info, Share2, Circle, Square, Hexagon, Play, Pause, Zap } from 'lucide-react';

export function DessinSection() {
  const [hoveredEdge, setHoveredEdge] = useState<number | null>(null);
  const [selectedEdge, setSelectedEdge] = useState<number | null>(null);
  const [hoveredVertex, setHoveredVertex] = useState<{type: 'black' | 'white', id: number} | null>(null);
  const [showLabels, setShowLabels] = useState(true);
  const [animationActive, setAnimationActive] = useState(false);
  const [animationProgress, setAnimationProgress] = useState(0);
  const [levelN, setLevelN] = useState<number>(4);
  const [kMultiplier, setKMultiplier] = useState<number>(1);
  const svgRef = useRef<SVGSVGElement>(null);
  const animationRef = useRef<number | null>(null);

  // Animation loop
  useEffect(() => {
    if (animationActive) {
      const animate = () => {
        setAnimationProgress(prev => (prev + 0.02) % 1);
        animationRef.current = requestAnimationFrame(animate);
      };
      animationRef.current = requestAnimationFrame(animate);
    } else {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    }
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [animationActive]);

  // Get particle data for an edge
  const getParticleForEdge = (edgeId: number) => {
    const edge = dessinEdges.find(e => e.id === edgeId);
    if (!edge) return null;
    return particlesWithDeltaK.find(p => p.name === edge.name);
  };

  // Check if edge should be highlighted based on level N
  const isEdgeAtLevel = (edgeId: number) => {
    const particle = getParticleForEdge(edgeId);
    if (!particle) return false;
    return particle.n === levelN;
  };

  // Get edge color based on particle type and state
  const getEdgeColor = (edge: typeof dessinEdges[0], isHovered: boolean, isSelected: boolean, isAtLevel: boolean) => {
    if (isSelected) return '#ef4444'; // red for selected
    if (isHovered) return '#f97316'; // orange for hovered
    if (isAtLevel) return '#10b981'; // emerald for matching level
    switch (edge.type) {
      case 'quark': return '#3b82f6'; // blue
      case 'lepton': return '#22c55e'; // green
      case 'boson': return '#a855f7'; // purple
      case 'anchor': return '#6b7280'; // gray
      default: return '#6b7280';
    }
  };

  // Get face color
  const getFaceColor = (size: number) => {
    switch (size) {
      case 6: return 'rgba(59, 130, 246, 0.15)'; // quarks
      case 3: return 'rgba(34, 197, 94, 0.15)'; // leptons
      case 2: return 'rgba(168, 85, 247, 0.15)'; // bosons
      case 1: return 'rgba(107, 114, 128, 0.15)'; // anchor
      default: return 'transparent';
    }
  };

  // Calculate edge path
  const getEdgePath = (edge: typeof dessinEdges[0]) => {
    const bv = dessinBlackVertices[edge.blackVertex];
    const wv = dessinWhiteVertices[edge.whiteVertex];
    return `M ${bv.x * 60 + 50} ${bv.y * 60 + 200} L ${wv.x * 60 + 50} ${wv.y * 60 + 200}`;
  };

  // Get point along edge for animation
  const getPointOnEdge = (edge: typeof dessinEdges[0], t: number) => {
    const bv = dessinBlackVertices[edge.blackVertex];
    const wv = dessinWhiteVertices[edge.whiteVertex];
    const x1 = bv.x * 60 + 50;
    const y1 = bv.y * 60 + 200;
    const x2 = wv.x * 60 + 50;
    const y2 = wv.y * 60 + 200;
    return {
      x: x1 + (x2 - x1) * t,
      y: y1 + (y2 - y1) * t
    };
  };

  // Check if vertex is connected to hovered edge
  const isVertexConnectedToHoveredEdge = (vertexType: 'black' | 'white', vertexId: number) => {
    if (hoveredEdge === null) return false;
    const edge = dessinEdges.find(e => e.id === hoveredEdge);
    if (!edge) return false;
    if (vertexType === 'black') return edge.blackVertex === vertexId;
    return edge.whiteVertex === vertexId;
  };

  // Get edges connected to a vertex
  const getEdgesConnectedToVertex = (vertexType: 'black' | 'white', vertexId: number) => {
    return dessinEdges.filter(edge => {
      if (vertexType === 'black') return edge.blackVertex === vertexId;
      return edge.whiteVertex === vertexId;
    });
  };

  // Calculate mass from formula
  const calculateMass = (n: number, K: number) => {
    return CONSTANTS.me * Math.pow(g, n) * K;
  };

  const selectedEdgeData = selectedEdge !== null ? dessinEdges.find(e => e.id === selectedEdge) : null;
  const selectedParticle = selectedEdgeData ? getParticleForEdge(selectedEdgeData.id) : null;
  const calculatedMass = selectedParticle ? calculateMass(selectedParticle.n, kMultiplier) : null;

  // Get particles at current level
  const particlesAtLevel = particlesWithDeltaK.filter(p => p.n === levelN);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Dessin d&apos;Enfant on X₀(6)</h2>
        <Badge variant="outline" className="text-sm">
          Theorem 4.10: Unique among 36 dessins
        </Badge>
      </div>

      <Tabs defaultValue="interactive" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="interactive">Interactive</TabsTrigger>
          <TabsTrigger value="visualization">Static</TabsTrigger>
          <TabsTrigger value="structure">Structure</TabsTrigger>
          <TabsTrigger value="properties">Properties</TabsTrigger>
        </TabsList>

        <TabsContent value="interactive" className="space-y-4">
          {/* Interactive Controls */}
          <Card className="bg-gradient-to-r from-blue-50 to-purple-50">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-yellow-500" />
                Interactive Controls
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Level N Slider */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Lattice Level n: {levelN}</span>
                    <Badge className="bg-blue-500">{particlesAtLevel.length} particles</Badge>
                  </div>
                  <Slider 
                    value={[levelN]} 
                    onValueChange={([v]) => setLevelN(v)} 
                    min={0} 
                    max={7} 
                    step={1} 
                  />
                  <div className="text-xs text-gray-500">
                    gⁿ = {Math.pow(g, levelN).toFixed(2)}
                  </div>
                  {particlesAtLevel.length > 0 && (
                    <div className="text-xs bg-white p-2 rounded">
                      {particlesAtLevel.map(p => p.name).join(', ')}
                    </div>
                  )}
                </div>

                {/* K Multiplier Slider */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">K Multiplier: {kMultiplier.toFixed(2)}</span>
                  </div>
                  <Slider 
                    value={[kMultiplier]} 
                    onValueChange={([v]) => setKMultiplier(v)} 
                    min={0.3} 
                    max={3} 
                    step={0.1} 
                  />
                  <div className="text-xs text-gray-500">
                    From B₁ = {'{1/3, 1/2, 2/3, 3/4, 1, 4/3, √2, 3/2, 2, 3}'}
                  </div>
                  {selectedParticle && (
                    <div className="text-xs bg-green-50 p-2 rounded">
                      m = {CONSTANTS.me.toFixed(2)} × {Math.pow(g, selectedParticle.n).toFixed(2)} × {kMultiplier.toFixed(2)} = <strong>{calculateMass(selectedParticle.n, kMultiplier).toFixed(2)} MeV</strong>
                    </div>
                  )}
                </div>

                {/* Animation Control */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Information Flow</span>
                  </div>
                  <Button
                    onClick={() => setAnimationActive(!animationActive)}
                    variant={animationActive ? "destructive" : "default"}
                    className="w-full"
                  >
                    {animationActive ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
                    {animationActive ? 'Stop Animation' : 'Start Animation'}
                  </Button>
                  <div className="text-xs text-gray-500">
                    Visualize how information propagates through the dessin
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Interactive Visualization */}
          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle>Interactive Graph</CardTitle>
                <div className="flex gap-2">
                  <button
                    onClick={() => setShowLabels(!showLabels)}
                    className="px-3 py-1 text-sm bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
                  >
                    {showLabels ? 'Hide Labels' : 'Show Labels'}
                  </button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col lg:flex-row gap-6">
                {/* SVG Visualization */}
                <div className="flex-1 bg-slate-50 rounded-lg p-4 overflow-auto">
                  <svg
                    ref={svgRef}
                    viewBox="0 0 650 400"
                    className="w-full max-w-2xl mx-auto"
                    style={{ minHeight: '300px' }}
                  >
                    {/* Face backgrounds */}
                    <polygon points="230,200 410,200 470,320 290,320 170,320" fill={getFaceColor(6)} stroke="none" />
                    <polygon points="290,80 410,80 470,200" fill={getFaceColor(3)} stroke="none" />
                    <polygon points="50,200 170,200 230,80" fill={getFaceColor(2)} stroke="none" />
                    <circle cx="110" cy="200" r="40" fill={getFaceColor(1)} stroke="none" />

                    {/* Edges */}
                    {dessinEdges.map((edge) => {
                      const isHovered = hoveredEdge === edge.id;
                      const isSelected = selectedEdge === edge.id;
                      const isAtLevel = isEdgeAtLevel(edge.id);
                      const isConnectedToHoveredVertex = hoveredVertex && 
                        ((hoveredVertex.type === 'black' && edge.blackVertex === hoveredVertex.id) ||
                         (hoveredVertex.type === 'white' && edge.whiteVertex === hoveredVertex.id));
                      
                      const color = getEdgeColor(edge, isHovered, isSelected, isAtLevel);
                      const strokeWidth = isHovered || isSelected || isConnectedToHoveredVertex ? 4 : 2;
                      const opacity = hoveredVertex && !isConnectedToHoveredVertex ? 0.3 : 1;

                      return (
                        <g key={edge.id}>
                          <path
                            d={getEdgePath(edge)}
                            stroke={color}
                            strokeWidth={strokeWidth}
                            fill="none"
                            opacity={opacity}
                            className="cursor-pointer transition-all duration-200"
                            onMouseEnter={() => setHoveredEdge(edge.id)}
                            onMouseLeave={() => setHoveredEdge(null)}
                            onClick={() => setSelectedEdge(edge.id === selectedEdge ? null : edge.id)}
                          />
                          {showLabels && (
                            <text
                              x={(dessinBlackVertices[edge.blackVertex].x * 60 + dessinWhiteVertices[edge.whiteVertex].x * 60) / 2 + 50}
                              y={(dessinBlackVertices[edge.blackVertex].y * 60 + dessinWhiteVertices[edge.whiteVertex].y * 60) / 2 + 200}
                              textAnchor="middle"
                              dominantBaseline="middle"
                              className="text-xs font-bold pointer-events-none"
                              fill={isSelected ? '#ef4444' : isAtLevel ? '#10b981' : '#374151'}
                              opacity={opacity}
                            >
                              {edge.name}
                            </text>
                          )}
                        </g>
                      );
                    })}

                    {/* Animation dots */}
                    {animationActive && dessinEdges.map((edge) => {
                      const particle = getParticleForEdge(edge.id);
                      if (!particle) return null;
                      const speed = 1 / (particle.n + 1); // Faster for lower n
                      const t = (animationProgress * speed * 3) % 1;
                      const point = getPointOnEdge(edge, t);
                      return (
                        <circle
                          key={`anim-${edge.id}`}
                          cx={point.x}
                          cy={point.y}
                          r={4}
                          fill="#fbbf24"
                          className="pointer-events-none"
                        />
                      );
                    })}

                    {/* Black vertices */}
                    {dessinBlackVertices.map((bv) => {
                      const isConnected = isVertexConnectedToHoveredEdge('black', bv.id);
                      const connectedEdges = getEdgesConnectedToVertex('black', bv.id);
                      const particlesAtThisVertex = connectedEdges.map(e => getParticleForEdge(e.id)).filter(Boolean);
                      const avgN = particlesAtThisVertex.length > 0 
                        ? particlesAtThisVertex.reduce((sum, p) => sum + (p?.n || 0), 0) / particlesAtThisVertex.length 
                        : 0;
                      
                      return (
                        <g key={`bv-${bv.id}`}
                          onMouseEnter={() => setHoveredVertex({type: 'black', id: bv.id})}
                          onMouseLeave={() => setHoveredVertex(null)}
                          className="cursor-pointer"
                        >
                          <circle
                            cx={bv.x * 60 + 50}
                            cy={bv.y * 60 + 200}
                            r={isConnected ? 16 : 12}
                            fill="black"
                            stroke={isConnected ? '#f97316' : 'white'}
                            strokeWidth={isConnected ? 4 : 2}
                            className="transition-all duration-200"
                          />
                          <text
                            x={bv.x * 60 + 50}
                            y={bv.y * 60 + 200 + 28}
                            textAnchor="middle"
                            className="text-xs fill-gray-600"
                          >
                            BV{bv.id} (⟨n⟩={avgN.toFixed(1)})
                          </text>
                        </g>
                      );
                    })}

                    {/* White vertices */}
                    {dessinWhiteVertices.map((wv) => {
                      const isConnected = isVertexConnectedToHoveredEdge('white', wv.id);
                      
                      return (
                        <g key={`wv-${wv.id}`}
                          onMouseEnter={() => setHoveredVertex({type: 'white', id: wv.id})}
                          onMouseLeave={() => setHoveredVertex(null)}
                          className="cursor-pointer"
                        >
                          <circle
                            cx={wv.x * 60 + 50}
                            cy={wv.y * 60 + 200}
                            r={isConnected ? 14 : 10}
                            fill="white"
                            stroke={isConnected ? '#f97316' : 'black'}
                            strokeWidth={isConnected ? 4 : 2}
                            className="transition-all duration-200"
                          />
                          <text
                            x={wv.x * 60 + 50}
                            y={wv.y * 60 + 200 - 20}
                            textAnchor="middle"
                            className="text-xs fill-gray-600"
                          >
                            WV{wv.id}
                          </text>
                        </g>
                      );
                    })}
                  </svg>
                </div>

                {/* Info Panel */}
                <div className="w-full lg:w-80 space-y-4">
                  {/* Legend */}
                  <div className="bg-slate-50 p-4 rounded-lg">
                    <h4 className="font-semibold mb-3">Legend</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded-full bg-black border-2 border-white" />
                        <span>Black vertex (d₂=3)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded-full bg-white border-2 border-black" />
                        <span>White vertex (d₁=2)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-1 bg-emerald-500" />
                        <span>At level n (selected)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-0.5 bg-blue-500" />
                        <span>Quark edge</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-0.5 bg-green-500" />
                        <span>Lepton edge</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-0.5 bg-purple-500" />
                        <span>Boson edge</span>
                      </div>
                    </div>
                  </div>

                  {/* Selected Edge Info */}
                  {selectedEdgeData && selectedParticle && (
                    <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                      <h4 className="font-semibold mb-2 flex items-center gap-2">
                        <Info className="w-4 h-4" />
                        Edge: {selectedEdgeData.name}
                      </h4>
                      <div className="space-y-1 text-sm">
                        <p><span className="text-gray-600">Type:</span> <span className="capitalize">{selectedEdgeData.type}</span></p>
                        <p><span className="text-gray-600">Level n:</span> {selectedParticle.n}</p>
                        <p><span className="text-gray-600">K:</span> {selectedParticle.K.toFixed(3)}</p>
                        <p><span className="text-gray-600">Predicted mass:</span> {selectedParticle.m_pred.toFixed(1)} MeV</p>
                        <p><span className="text-gray-600">Experimental:</span> {selectedParticle.m_exp.toFixed(1)} MeV</p>
                        {calculatedMass && (
                          <div className="mt-2 p-2 bg-white rounded">
                            <p className="text-xs text-gray-500">With K = {kMultiplier.toFixed(2)}:</p>
                            <p className="font-mono font-bold">{calculatedMass.toFixed(2)} MeV</p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Formula */}
                  <div className="bg-gradient-to-r from-purple-50 to-blue-50 p-4 rounded-lg">
                    <h4 className="font-semibold mb-2">Mass Formula</h4>
                    <div className="text-center font-mono text-lg">
                      m = mₑ · gⁿ · K
                    </div>
                    <div className="text-center text-sm text-gray-500 mt-1">
                      g = {g.toFixed(4)} ≈ μ^(1/4)
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="visualization" className="space-y-4">
          {/* Static visualization - same as before */}
          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle>Static Dessin View</CardTitle>
                <div className="flex gap-2">
                  <button
                    onClick={() => setShowLabels(!showLabels)}
                    className="px-3 py-1 text-sm bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
                  >
                    {showLabels ? 'Hide Labels' : 'Show Labels'}
                  </button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col lg:flex-row gap-6">
                <div className="flex-1 bg-slate-50 rounded-lg p-4 overflow-auto">
                  <svg viewBox="0 0 650 400" className="w-full max-w-2xl mx-auto" style={{ minHeight: '300px' }}>
                    <polygon points="230,200 410,200 470,320 290,320 170,320" fill={getFaceColor(6)} stroke="none" />
                    <polygon points="290,80 410,80 470,200" fill={getFaceColor(3)} stroke="none" />
                    <polygon points="50,200 170,200 230,80" fill={getFaceColor(2)} stroke="none" />
                    <circle cx="110" cy="200" r="40" fill={getFaceColor(1)} stroke="none" />

                    {dessinEdges.map((edge) => {
                      const isHovered = hoveredEdge === edge.id;
                      const isSelected = selectedEdge === edge.id;
                      const color = getEdgeColor(edge, isHovered, isSelected, false);
                      return (
                        <g key={edge.id}>
                          <path
                            d={getEdgePath(edge)}
                            stroke={color}
                            strokeWidth={isHovered || isSelected ? 4 : 2}
                            fill="none"
                            className="cursor-pointer transition-all duration-200"
                            onMouseEnter={() => setHoveredEdge(edge.id)}
                            onMouseLeave={() => setHoveredEdge(null)}
                            onClick={() => setSelectedEdge(edge.id === selectedEdge ? null : edge.id)}
                          />
                          {showLabels && (
                            <text
                              x={(dessinBlackVertices[edge.blackVertex].x * 60 + dessinWhiteVertices[edge.whiteVertex].x * 60) / 2 + 50}
                              y={(dessinBlackVertices[edge.blackVertex].y * 60 + dessinWhiteVertices[edge.whiteVertex].y * 60) / 2 + 200}
                              textAnchor="middle"
                              dominantBaseline="middle"
                              className="text-xs font-bold pointer-events-none"
                              fill={isSelected ? '#ef4444' : '#374151'}
                            >
                              {edge.name}
                            </text>
                          )}
                        </g>
                      );
                    })}

                    {dessinBlackVertices.map((bv) => (
                      <g key={`bv-${bv.id}`}>
                        <circle cx={bv.x * 60 + 50} cy={bv.y * 60 + 200} r={12} fill="black" stroke="white" strokeWidth={2} />
                        <text x={bv.x * 60 + 50} y={bv.y * 60 + 200 + 25} textAnchor="middle" className="text-xs fill-gray-600">BV{bv.id}</text>
                      </g>
                    ))}

                    {dessinWhiteVertices.map((wv) => (
                      <g key={`wv-${wv.id}`}>
                        <circle cx={wv.x * 60 + 50} cy={wv.y * 60 + 200} r={10} fill="white" stroke="black" strokeWidth={2} />
                        <text x={wv.x * 60 + 50} y={wv.y * 60 + 200 - 18} textAnchor="middle" className="text-xs fill-gray-600">WV{wv.id}</text>
                      </g>
                    ))}
                  </svg>
                </div>

                <div className="w-full lg:w-80 space-y-4">
                  <div className="bg-slate-50 p-4 rounded-lg">
                    <h4 className="font-semibold mb-3">Legend</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2"><div className="w-4 h-4 rounded-full bg-black border-2 border-white" /><span>Black vertex (d₂=3)</span></div>
                      <div className="flex items-center gap-2"><div className="w-4 h-4 rounded-full bg-white border-2 border-black" /><span>White vertex (d₁=2)</span></div>
                      <div className="flex items-center gap-2"><div className="w-8 h-0.5 bg-blue-500" /><span>Quark edge</span></div>
                      <div className="flex items-center gap-2"><div className="w-8 h-0.5 bg-green-500" /><span>Lepton edge</span></div>
                      <div className="flex items-center gap-2"><div className="w-8 h-0.5 bg-purple-500" /><span>Boson edge</span></div>
                      <div className="flex items-center gap-2"><div className="w-8 h-0.5 bg-gray-500" /><span>Anchor edge</span></div>
                    </div>
                  </div>

                  <div className="bg-slate-50 p-4 rounded-lg">
                    <h4 className="font-semibold mb-3">Dessin Statistics</h4>
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="text-center p-2 bg-white rounded"><div className="text-2xl font-bold text-black">4</div><div className="text-xs text-gray-500">Black vertices</div></div>
                      <div className="text-center p-2 bg-white rounded"><div className="text-2xl font-bold text-gray-700">6</div><div className="text-xs text-gray-500">White vertices</div></div>
                      <div className="text-center p-2 bg-white rounded"><div className="text-2xl font-bold text-blue-600">12</div><div className="text-xs text-gray-500">Edges (=index)</div></div>
                      <div className="text-center p-2 bg-white rounded"><div className="text-2xl font-bold text-purple-600">4</div><div className="text-xs text-gray-500">Faces</div></div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-blue-50/50"><CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Hexagon className="w-4 h-4" />Quark Face (6)</CardTitle></CardHeader><CardContent><div className="text-sm space-y-1"><p><span className="font-medium">u, d, s, c, b, t</span></p><p className="text-xs text-gray-500">6 quark edges</p></div></CardContent></Card>
            <Card className="bg-green-50/50"><CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Share2 className="w-4 h-4" />Lepton Face (3)</CardTitle></CardHeader><CardContent><div className="text-sm space-y-1"><p><span className="font-medium">μ, τ</span></p><p className="text-xs text-gray-500">+ p (shared)</p></div></CardContent></Card>
            <Card className="bg-purple-50/50"><CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Square className="w-4 h-4" />Boson Face (2)</CardTitle></CardHeader><CardContent><div className="text-sm space-y-1"><p><span className="font-medium">W, H</span></p><p className="text-xs text-gray-500">Pre-EWSB content</p></div></CardContent></Card>
            <Card className="bg-gray-50/50"><CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Circle className="w-4 h-4" />Anchor Face (1)</CardTitle></CardHeader><CardContent><div className="text-sm space-y-1"><p><span className="font-medium">e</span></p><p className="text-xs text-gray-500">Electron anchor</p></div></CardContent></Card>
          </div>
        </TabsContent>

        <TabsContent value="structure" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>Ramification Structure</CardTitle></CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50">
                    <tr><th className="p-2 text-left">j-fibre</th><th className="p-2 text-left">Ramification</th><th className="p-2 text-left">e</th><th className="p-2 text-left">Preimages</th><th className="p-2 text-left">Σ(e-1)</th><th className="p-2 text-left">Physics</th></tr>
                  </thead>
                  <tbody>
                    <tr className="border-b"><td className="p-2 font-medium">j = 0</td><td className="p-2">d₂ = 3 (uniform)</td><td className="p-2">3</td><td className="p-2">index/d₂ = 4</td><td className="p-2">8</td><td className="p-2 text-blue-600">colour</td></tr>
                    <tr className="border-b"><td className="p-2 font-medium">j = 1728</td><td className="p-2">d₁ = 2 (uniform)</td><td className="p-2">2</td><td className="p-2">index/d₁ = 6</td><td className="p-2">6</td><td className="p-2 text-green-600">isospin</td></tr>
                    <tr className="border-b"><td className="p-2 font-medium">j = ∞</td><td className="p-2">{'{6,3,2,1}'}</td><td className="p-2">-</td><td className="p-2">4 cusps</td><td className="p-2">8</td><td className="p-2 text-purple-600">particle type</td></tr>
                    <tr className="bg-slate-50 font-medium"><td className="p-2">Total</td><td className="p-2">R</td><td className="p-2"></td><td className="p-2"></td><td className="p-2">22</td><td className="p-2"></td></tr>
                  </tbody>
                </table>
              </div>
              <div className="mt-4 p-3 bg-green-50 rounded-lg text-sm"><span className="font-medium">Riemann-Hurwitz check:</span> 2g - 2 = 12(-2) + 22 = -2, giving g = 0 ✓</div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader><CardTitle>Monodromy Group</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-slate-50 rounded"><span className="font-medium">Group</span><span className="font-mono">PSL₂(ℤ/6ℤ)</span></div>
                <div className="flex items-center justify-between p-3 bg-slate-50 rounded"><span className="font-medium">Order</span><span className="text-2xl font-bold text-blue-600">72</span></div>
                <div className="flex items-center justify-between p-3 bg-slate-50 rounded"><span className="font-medium">|Aut|</span><span className="text-2xl font-bold text-green-600">1</span></div>
                <p className="text-sm text-gray-500 mt-2">The dessin is unique: all 36 connected dessins with ramification type (3⁴, 2⁶, 6+3+2+1) are isomorphic.</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle>Cusp-Representation Correspondence</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                <div className="text-center p-4 bg-blue-50 rounded-lg"><div className="text-lg font-medium mb-2">Cusp widths = Div(N)</div><div className="text-2xl font-bold text-blue-600">{'{1, 2, 3, 6}'}</div></div>
                <div className="text-center p-4 bg-purple-50 rounded-lg"><div className="text-lg font-medium mb-2">SM gauge dimensions</div><div className="text-2xl font-bold text-purple-600">U(1) × SU(2) × SU(3)</div></div>
                <p className="text-sm text-gray-500 text-center">Theorem 4.2: N = 6 is unique with this property</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="properties" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>Modular Properties of Γ₀(6)</CardTitle></CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {modularProperties.map((prop) => (
                  <div key={prop.key} className="p-3 bg-slate-50 rounded-lg">
                    <div className="text-xs text-gray-500 mb-1">{prop.key}</div>
                    <div className="font-medium">{Array.isArray(prop.value) ? `[${prop.value.join(', ')}]` : prop.value}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader><CardTitle>Biadjacency Matrix B (4×6)</CardTitle></CardHeader>
              <CardContent>
                <div className="font-mono text-sm bg-slate-50 p-4 rounded-lg overflow-x-auto">
                  <div className="grid grid-cols-6 gap-2 text-center">
                    <div className="bg-blue-100 p-2 rounded">2</div><div className="bg-blue-100 p-2 rounded">1</div><div className="bg-gray-100 p-2 rounded">0</div><div className="bg-gray-100 p-2 rounded">0</div><div className="bg-gray-100 p-2 rounded">0</div><div className="bg-gray-100 p-2 rounded">0</div>
                    <div className="bg-gray-100 p-2 rounded">0</div><div className="bg-blue-100 p-2 rounded">1</div><div className="bg-blue-100 p-2 rounded">1</div><div className="bg-gray-100 p-2 rounded">0</div><div className="bg-blue-100 p-2 rounded">1</div><div className="bg-gray-100 p-2 rounded">0</div>
                    <div className="bg-gray-100 p-2 rounded">0</div><div className="bg-gray-100 p-2 rounded">0</div><div className="bg-blue-100 p-2 rounded">1</div><div className="bg-blue-100 p-2 rounded">1</div><div className="bg-gray-100 p-2 rounded">0</div><div className="bg-blue-100 p-2 rounded">1</div>
                    <div className="bg-gray-100 p-2 rounded">0</div><div className="bg-gray-100 p-2 rounded">0</div><div className="bg-gray-100 p-2 rounded">0</div><div className="bg-blue-100 p-2 rounded">1</div><div className="bg-blue-100 p-2 rounded">1</div><div className="bg-blue-100 p-2 rounded">1</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle>BBT Spectrum (Theorem 4.15)</CardTitle></CardHeader>
              <CardContent>
                <div className="text-center p-4 bg-gradient-to-r from-yellow-50 to-gray-50 rounded-lg"><div className="text-lg mb-2">σ²(B) = {'{N, N-1, d₁, 1}'}</div><div className="text-3xl font-bold text-blue-600">{'{6, 5, 2, 1}'}</div></div>
                <div className="mt-4 space-y-2">
                  <div className="flex justify-between items-center p-2 bg-yellow-50 rounded"><span>λ₁ = 6 (= N)</span><Badge>Gold</Badge></div>
                  <div className="flex justify-between items-center p-2 bg-gray-100 rounded"><span>λ₂ = 5 (= N-1)</span><Badge variant="secondary">Silver</Badge></div>
                  <div className="flex justify-between items-center p-2 bg-orange-50 rounded"><span>λ₃ = 2 (= d₁)</span><Badge className="bg-orange-500">Bronze</Badge></div>
                  <div className="flex justify-between items-center p-2 bg-gray-200 rounded"><span>λ₄ = 1</span><Badge variant="outline">Unity</Badge></div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
