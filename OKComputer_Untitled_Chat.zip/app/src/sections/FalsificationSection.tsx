import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { falsificationPredictions } from '@/data/modelData';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from 'recharts';

export function FalsificationSection() {
  const allPredictions = [
    ...falsificationPredictions.numerical.map(p => ({ ...p, category: 'Numerical' })),
    ...falsificationPredictions.structural.map(p => ({ ...p, category: 'Structural' }))
  ];

  const chartData = allPredictions.map(p => ({
    name: p.name.length > 25 ? p.name.slice(0, 25) + '...' : p.name,
    year: p.year,
    category: p.category,
    status: p.status
  }));

  const getStatusColor = (status: string) => {
    if (status.includes('✅')) return '#22c55e';
    if (status.includes('⏳')) return '#f97316';
    return '#ef4444';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Falsification Map</h2>
        <Badge variant="outline">§9</Badge>
      </div>

      {/* Timeline */}
      <Card>
        <CardHeader>
          <CardTitle>Test Timeline</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <BarChart 
              data={chartData} 
              layout="vertical"
              margin={{ top: 20, right: 100, bottom: 20, left: 180 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                type="number" 
                domain={[2025, 2032]}
                label={{ value: 'Test Year', position: 'bottom' }}
              />
              <YAxis 
                type="category" 
                dataKey="name" 
                width={170}
                tick={{ fontSize: 10 }}
              />
              <Tooltip 
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="bg-white p-2 border rounded shadow">
                        <p className="font-bold">{data.name}</p>
                        <p>Year: {data.year}</p>
                        <p>Category: {data.category}</p>
                        <p>Status: {data.status}</p>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Bar dataKey="year">
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={getStatusColor(entry.status)} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Numerical Predictions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Badge className="bg-blue-500">7 Predictions</Badge>
            Numerical Predictions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Prediction</TableHead>
                <TableHead>Experiment</TableHead>
                <TableHead>Year</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {falsificationPredictions.numerical.map((p, i) => (
                <TableRow key={i}>
                  <TableCell className="font-medium">{p.name}</TableCell>
                  <TableCell>{p.experiment}</TableCell>
                  <TableCell>{p.year}</TableCell>
                  <TableCell>
                    <Badge 
                      variant={p.status.includes('✅') ? 'default' : 'secondary'}
                      className={p.status.includes('✅') ? 'bg-green-500' : 'bg-orange-500'}
                    >
                      {p.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Structural Predictions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Badge className="bg-purple-500">6 Predictions</Badge>
            Structural Predictions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Prediction</TableHead>
                <TableHead>Experiment</TableHead>
                <TableHead>Year</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {falsificationPredictions.structural.map((p, i) => (
                <TableRow key={i}>
                  <TableCell className="font-medium">{p.name}</TableCell>
                  <TableCell>{p.experiment}</TableCell>
                  <TableCell>{p.year}</TableCell>
                  <TableCell>
                    <Badge 
                      variant={p.status.includes('✅') ? 'default' : 'secondary'}
                      className={p.status.includes('✅') ? 'bg-green-500' : 'bg-orange-500'}
                    >
                      {p.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Comparison Table */}
      <Card className="bg-slate-50">
        <CardHeader>
          <CardTitle>Comparison with Other Models</CardTitle>
        </CardHeader>
        <CardContent>
          <table className="w-full text-sm">
            <thead className="bg-white">
              <tr>
                <th className="p-2 text-left">Question</th>
                <th className="p-2 text-left">LD</th>
                <th className="p-2 text-left">SUSY/GUT</th>
                <th className="p-2 text-left">Flavour Symmetry</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b">
                <td className="p-2">Neutrino ordering</td>
                <td className="p-2 text-green-600 font-medium">NO only</td>
                <td className="p-2">both</td>
                <td className="p-2">both</td>
              </tr>
              <tr className="border-b">
                <td className="p-2">Proton decay</td>
                <td className="p-2 text-green-600 font-medium">stable</td>
                <td className="p-2">decays (τ~10³⁴yr)</td>
                <td className="p-2">model-dep.</td>
              </tr>
              <tr className="border-b">
                <td className="p-2">Higgs sector</td>
                <td className="p-2 text-green-600 font-medium">1 doublet</td>
                <td className="p-2">≥ 2 doublets</td>
                <td className="p-2">1 or more</td>
              </tr>
              <tr className="border-b">
                <td className="p-2">G origin</td>
                <td className="p-2 text-green-600 font-medium">= f(α,μ,mₑ)</td>
                <td className="p-2">compactification</td>
                <td className="p-2">unrelated</td>
              </tr>
              <tr className="border-b">
                <td className="p-2">Dark matter</td>
                <td className="p-2 text-green-600 font-medium">no candidate</td>
                <td className="p-2">neutralino</td>
                <td className="p-2">sterile ν</td>
              </tr>
              <tr>
                <td className="p-2">n=2 desert</td>
                <td className="p-2 text-green-600 font-medium">predicted</td>
                <td className="p-2">not constrained</td>
                <td className="p-2">not constrained</td>
              </tr>
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}
