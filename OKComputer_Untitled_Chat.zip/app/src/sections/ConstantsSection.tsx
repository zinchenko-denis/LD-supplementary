import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CONSTANTS, g, alpha_2pi, mu_0, mu_0_error } from '@/data/modelData';

export function ConstantsSection() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Fundamental Constants</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Electron Mass</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{CONSTANTS.me.toFixed(6)}</div>
            <div className="text-xs text-muted-foreground">MeV (CODATA 2018)</div>
            <div className="mt-2 text-xs bg-blue-50 p-2 rounded">
              Sole dimensionful input
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Proton/Electron Ratio μ</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{CONSTANTS.mu.toFixed(6)}</div>
            <div className="text-xs text-muted-foreground">Dimensionless</div>
            <div className="mt-2 text-xs bg-green-50 p-2 rounded">
              μ = 6π⁵ × (1 + 10α²/9π + ...) ≈ 1836.12
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Scaling Factor g = μ^(1/4)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{g.toFixed(6)}</div>
            <div className="text-xs text-muted-foreground">Lattice step</div>
            <div className="mt-2 text-xs bg-blue-50 p-2 rounded">
              Unique coarsest base placing all particles within 6%
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Fine Structure Constant</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold">α⁻¹ = {CONSTANTS.alpha_inv.toFixed(6)}</div>
            <div className="text-xs text-muted-foreground">α = {CONSTANTS.alpha.toExponential(6)}</div>
            <div className="mt-2 text-xs bg-purple-50 p-2 rounded">
              Predicted to 0.001 ppb from cusp data
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Weyl Coupling</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{alpha_2pi.toExponential(4)}</div>
            <div className="text-xs text-muted-foreground">α/(2π)</div>
            <div className="mt-2 text-xs bg-yellow-50 p-2 rounded">
              Theorem 6.4: Unique at d=4, Tr=2
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Gravitational Constant G</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold">{CONSTANTS.G.toExponential(4)}</div>
            <div className="text-xs text-muted-foreground">m³/(kg·s²)</div>
            <div className="mt-2 text-xs bg-orange-50 p-2 rounded">
              Ring-closure condition (§7)
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Lenz Formula */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Badge className="bg-blue-500">Lenz (1951)</Badge>
            μ = 6π⁵ Formula
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-sm text-gray-500 mb-1">Leading Order</div>
              <div className="text-3xl font-bold text-blue-600">6π⁵</div>
              <div className="text-lg">= {mu_0.toFixed(2)}</div>
            </div>
            <div className="text-center">
              <div className="text-sm text-gray-500 mb-1">Experimental</div>
              <div className="text-3xl font-bold text-green-600">{CONSTANTS.mu.toFixed(2)}</div>
              <div className="text-lg">(CODATA)</div>
            </div>
            <div className="text-center">
              <div className="text-sm text-gray-500 mb-1">Deviation</div>
              <div className="text-3xl font-bold text-orange-600">{(mu_0_error * 1e6).toFixed(2)}</div>
              <div className="text-lg">ppm</div>
            </div>
          </div>
          
          <div className="mt-6 p-4 bg-white/70 rounded-lg">
            <div className="text-center text-lg font-medium mb-2">
              Full Formula (Theorem 5.1)
            </div>
            <div className="text-center text-xl font-mono">
              μ = 6π⁵ × [1 + (10α²/9π) + Σ cₙ(α/π)ⁿ]
            </div>
            <div className="text-center text-sm text-gray-500 mt-2">
              where cₙ = -(2n-1)/(2n+3) from Riemann-Roch on X₀(6)
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
