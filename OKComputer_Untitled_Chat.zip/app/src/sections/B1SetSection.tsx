import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { B1Set } from '@/data/modelData';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from 'recharts';

export function B1SetSection() {
  const tcData = B1Set.map(el => ({
    label: el.label,
    tc: el.tc
  }));

  const totalTC = B1Set.reduce((sum, el) => sum + el.tc, 0);
  const meanTC = totalTC / B1Set.length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">The Set B₁</h2>
        <Badge variant="outline">Definition 3.4</Badge>
      </div>

      <Card className="bg-gradient-to-r from-blue-50 to-purple-50">
        <CardHeader>
          <CardTitle>Definition</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-xl font-mono mb-4">
            B₁ = {'{2^a · 3^b : |a|+|b| ≤ 3, 1/3 ≤ 2^a · 3^b ≤ 3}'} ∪ {'{√2}'}
          </div>
          <div className="text-center text-lg">
            Explicitly: <span className="font-mono font-bold">{'{1/3, 1/2, 2/3, 3/4, 1, 4/3, √2, 3/2, 2, 3}'}</span>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {B1Set.map((el, i) => (
          <Card key={i} className={el.tc <= 1 ? 'bg-green-50' : el.tc <= 2 ? 'bg-blue-50' : 'bg-gray-50'}>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold mb-1">{el.label}</div>
              <div className="text-xs text-gray-500">{el.formula}</div>
              <div className="mt-2">
                <Badge variant={el.tc <= 1 ? 'default' : 'secondary'} className="text-xs">
                  TC = {el.tc}
                </Badge>
              </div>
              <div className="text-xs text-gray-400 mt-1">
                ≈ {el.value.toFixed(4)}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Tree Complexity (TC)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={tcData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="label" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="tc">
                  {tcData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.tc <= 1 ? '#22c55e' : entry.tc <= 2 ? '#3b82f6' : '#9ca3af'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
            <div className="mt-4 grid grid-cols-2 gap-4">
              <div className="text-center p-3 bg-green-50 rounded">
                <div className="text-2xl font-bold text-green-600">{totalTC}</div>
                <div className="text-xs text-gray-500">Total TC</div>
              </div>
              <div className="text-center p-3 bg-blue-50 rounded">
                <div className="text-2xl font-bold text-blue-600">{meanTC.toFixed(1)}</div>
                <div className="text-xs text-gray-500">Mean TC</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Statistical Significance</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 bg-green-50 rounded-lg">
              <div className="flex justify-between items-center">
                <span>B₁ total TC:</span>
                <span className="font-bold text-green-600">{totalTC}</span>
              </div>
              <div className="flex justify-between items-center mt-2">
                <span>Random subset (TC≤5):</span>
                <span className="font-bold">45.8 ± 2.4</span>
              </div>
              <div className="flex justify-between items-center mt-2 pt-2 border-t">
                <span>Deviation:</span>
                <span className="font-bold text-red-600">-10.2σ</span>
              </div>
            </div>

            <div className="p-4 bg-blue-50 rounded-lg">
              <div className="text-sm font-medium mb-2">Theorem 3.2: Generator Uniqueness</div>
              <p className="text-sm text-gray-600">
                Among 36 prime pairs ⟨p,q⟩ with p,q ≤ 23, the pair ⟨2,3⟩ is the unique 
                generator set for which all 10 non-anchor particles are matched within 6%.
              </p>
              <div className="mt-2 flex justify-between">
                <span className="text-sm">BIC (⟨2,3⟩):</span>
                <span className="font-bold text-green-600">-49.3</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">BIC (⟨3,13⟩, 2nd):</span>
                <span className="font-bold text-orange-600">-26.2</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Theorem 4.6: Hecke Orbit</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center mb-4">
            <p className="text-lg">B₁ \ {'{√2}'} is the orbit of K = 1 under ⟨T₂, T₃⟩ at graph distance ≤ 3 in [1/3, 3]</p>
          </div>
          <div className="flex items-center justify-center gap-4 flex-wrap">
            <div className="text-center p-3 bg-blue-100 rounded-lg">
              <div className="font-bold">1</div>
              <div className="text-xs">Start</div>
            </div>
            <div className="text-2xl">→</div>
            <div className="text-center p-3 bg-green-100 rounded-lg">
              <div className="font-bold">{'{1/2, 2, 1/3, 3}'}</div>
              <div className="text-xs">Distance 1</div>
            </div>
            <div className="text-2xl">→</div>
            <div className="text-center p-3 bg-yellow-100 rounded-lg">
              <div className="font-bold">{'{1/4→3/4, 2/3, 3/2}'}</div>
              <div className="text-xs">Distance 2-3</div>
            </div>
          </div>
          <p className="text-center text-sm text-gray-500 mt-4">
            The MDL generators ⟨2,3⟩ and the Hecke algebra ⟨T₂, T₃⟩ are identical
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
