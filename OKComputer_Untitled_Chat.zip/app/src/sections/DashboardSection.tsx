import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableRow } from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { allTests, rms, pJoint, signsMatch } from '@/data/modelData';
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid
} from 'recharts';

export function DashboardSection() {
  const passed = allTests.filter(t => t.status === 'passed').length;
  const pending = allTests.filter(t => t.status === 'pending').length;
  const failed = allTests.filter(t => t.status === 'failed').length;
  const total = allTests.length;
  const successRate = (passed / total) * 100;

  const pieData = [
    { name: 'Passed', value: passed, color: '#22c55e' },
    { name: 'Pending', value: pending, color: '#f97316' },
    { name: 'Failed', value: failed, color: '#ef4444' },
  ];

  const topTests = allTests.slice(0, 8);

  const statsData = [
    { name: 'RMS', value: rms, unit: '%', color: '#22c55e' },
    { name: 'p-value', value: -Math.log10(pJoint), unit: '-log₁₀(p)', color: '#3b82f6' },
    { name: 'Signs', value: signsMatch, unit: '/10', color: '#a855f7' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Dashboard</h2>
        <Badge variant="outline">Overview</Badge>
      </div>

      {/* Main Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Overall Success Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-center py-8">
              <div className="text-center">
                <div className="text-6xl font-bold text-green-600">{successRate.toFixed(0)}%</div>
                <div className="text-lg text-muted-foreground mt-2">
                  {passed}/{total} tests passed
                </div>
                <div className="mt-4 flex gap-4 justify-center">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">{passed}</div>
                    <div className="text-xs text-muted-foreground">✓ Passed</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-orange-500">{pending}</div>
                    <div className="text-xs text-muted-foreground">⏳ Pending</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-red-500">{failed}</div>
                    <div className="text-xs text-muted-foreground">✗ Failed</div>
                  </div>
                </div>
              </div>
            </div>
            <Progress value={successRate} className="h-3" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Key Statistics</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={150}>
              <BarChart data={statsData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis dataKey="name" type="category" width={60} />
                <Tooltip />
                <Bar dataKey="value">
                  {statsData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
            <div className="mt-4 space-y-2 text-sm">
              <div className="flex justify-between">
                <span>RMS deviation:</span>
                <span className="font-bold text-green-600">{rms.toFixed(2)}%</span>
              </div>
              <div className="flex justify-between">
                <span>Joint p-value:</span>
                <span className="font-bold text-blue-600">{pJoint.toExponential(1)}</span>
              </div>
              <div className="flex justify-between">
                <span>Sign matches:</span>
                <span className="font-bold text-purple-600">{signsMatch}/10</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Test Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={70}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Top Tests</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableBody>
                {topTests.map((t, i) => (
                  <TableRow key={i}>
                    <TableCell className="py-1">
                      {t.status === 'passed' ? (
                        <span className="text-green-600">✓</span>
                      ) : t.status === 'pending' ? (
                        <span className="text-orange-500">⏳</span>
                      ) : (
                        <span className="text-red-500">✗</span>
                      )}
                    </TableCell>
                    <TableCell className="py-1 text-sm">{t.test}</TableCell>
                    <TableCell className="py-1 text-sm text-right text-muted-foreground">{t.result}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* All Tests */}
      <Card>
        <CardHeader>
          <CardTitle>All Tests</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="max-h-[400px] overflow-y-auto">
            <Table>
              <TableBody>
                {allTests.map((t, i) => (
                  <TableRow key={i}>
                    <TableCell className="py-1">
                      {t.status === 'passed' ? (
                        <span className="text-green-600">✓</span>
                      ) : t.status === 'pending' ? (
                        <span className="text-orange-500">⏳</span>
                      ) : (
                        <span className="text-red-500">✗</span>
                      )}
                    </TableCell>
                    <TableCell className="py-1 text-sm">{t.test}</TableCell>
                    <TableCell className="py-1 text-sm text-right text-muted-foreground">{t.result}</TableCell>
                    <TableCell className="py-1 text-sm text-right text-gray-400">{t.reference}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Final Summary */}
      <div className="bg-gradient-to-r from-blue-50 to-green-50 border border-green-200 rounded-lg p-6">
        <div className="text-center">
          <div className="text-2xl font-bold text-green-700 mb-2">
            🏆 FINAL SUMMARY
          </div>
          <div className="text-lg">
            LD Framework passed <span className="font-bold text-green-600">{passed}/{total}</span> tests 
            ({successRate.toFixed(0)}%)
          </div>
          <div className="mt-4 grid grid-cols-3 gap-4 max-w-md mx-auto">
            <div className="bg-white rounded-lg p-3 shadow">
              <div className="text-2xl font-bold text-green-600">{passed}</div>
              <div className="text-xs text-muted-foreground">Passed</div>
            </div>
            <div className="bg-white rounded-lg p-3 shadow">
              <div className="text-2xl font-bold text-orange-500">{pending}</div>
              <div className="text-xs text-muted-foreground">Pending</div>
            </div>
            <div className="bg-white rounded-lg p-3 shadow">
              <div className="text-2xl font-bold text-red-500">{failed}</div>
              <div className="text-xs text-muted-foreground">Failed</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
