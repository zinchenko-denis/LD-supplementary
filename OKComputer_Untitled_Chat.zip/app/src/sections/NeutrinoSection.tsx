import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { 
  neutrinos, 
  sum_m_nu, 
  dm2_21, 
  dm2_31,
  sin2theta12_pred,
  sin2theta12_exp,
  sin2theta12_err,
  pull_juno,
  laplacianEigenvalues
} from '@/data/modelData';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell,
  LineChart,
  Line
} from 'recharts';
import { useMemo } from 'react';

export function NeutrinoSection() {
  const neutrinoData = neutrinos.map(n => ({
    name: n.name,
    mass: n.m_pred
  }));

  const tbm = 1/3;
  const pull_tbm = (tbm - sin2theta12_exp) / sin2theta12_err;

  // Heat kernel data
  const heatKernelData = useMemo(() => {
    const tValues = Array.from({ length: 100 }, (_, i) => 0.1 + (i * 1.9) / 99);
    return tValues.map(t => {
      const trace = laplacianEigenvalues
        .filter(lam => lam > 0)
        .reduce((sum, lam) => sum + Math.exp(-lam * t), 0);
      return { t, trace };
    });
  }, []);

  const tHalf = 0.5;
  const HTraceAtHalf = laplacianEigenvalues
    .filter(lam => lam > 0)
    .reduce((sum, lam) => sum + Math.exp(-lam * tHalf), 0);

  const U0_squared = 0.30769089;
  const target = 4/13;
  const ppmDiff = Math.abs(U0_squared - target) / target * 1e6;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Neutrino Sector & PMNS</h2>
        <Badge variant="outline">§8</Badge>
      </div>

      {/* Neutrino Masses */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Neutrino Masses</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={neutrinoData} margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis label={{ value: 'Mass (meV)', angle: -90, position: 'insideLeft' }} />
                <Tooltip />
                <Bar dataKey="mass" fill="#8b5cf6">
                  {neutrinoData.map((_entry, index) => (
                    <Cell key={`cell-${index}`} fill={['#a78bfa', '#8b5cf6', '#7c3aed'][index]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>sin²θ₁₂: Prediction vs JUNO 2025</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="flex justify-between items-center p-4 bg-blue-50 rounded-lg">
                <div>
                  <div className="text-sm text-muted-foreground">LD Prediction</div>
                  <div className="text-2xl font-bold text-blue-600">4/13 = {sin2theta12_pred.toFixed(7)}</div>
                </div>
                <div className="text-right">
                  <div className="text-sm text-muted-foreground">JUNO 2025</div>
                  <div className="text-2xl font-bold">{sin2theta12_exp.toFixed(4)} ± {sin2theta12_err.toFixed(4)}</div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>3σ range</span>
                  <span>Pull: {pull_juno > 0 ? '+' : ''}{pull_juno.toFixed(2)}σ</span>
                </div>
                <div className="relative h-6 bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className="absolute h-full bg-green-200 rounded-full"
                    style={{ 
                      left: `${((sin2theta12_exp - 3 * sin2theta12_err - 0.28) / (0.35 - 0.28)) * 100}%`,
                      width: `${(6 * sin2theta12_err / (0.35 - 0.28)) * 100}%`
                    }}
                  />
                  <div 
                    className="absolute w-1.5 h-full bg-blue-600"
                    style={{ left: `${((sin2theta12_pred - 0.28) / (0.35 - 0.28)) * 100}%` }}
                  />
                  <div 
                    className="absolute w-0.5 h-full bg-green-700"
                    style={{ left: `${((sin2theta12_exp - 0.28) / (0.35 - 0.28)) * 100}%` }}
                  />
                </div>
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>0.28</span>
                  <span className="text-green-700 font-medium">{sin2theta12_exp.toFixed(3)}</span>
                  <span>0.35</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-green-50 p-3 rounded-lg text-center">
                  <div className="text-sm text-muted-foreground">LD Model</div>
                  <div className="text-lg font-bold text-green-600">Pull: {pull_juno > 0 ? '+' : ''}{pull_juno.toFixed(2)}σ ✓</div>
                </div>
                <div className="bg-red-50 p-3 rounded-lg text-center">
                  <div className="text-sm text-muted-foreground">TBM (1/3)</div>
                  <div className="text-lg font-bold text-red-500">Pull: {pull_tbm > 0 ? '+' : ''}{pull_tbm.toFixed(2)}σ ✗</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Neutrino Table */}
      <Card>
        <CardHeader>
          <CardTitle>Neutrino Mass Predictions</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Neutrino</TableHead>
                <TableHead>n</TableHead>
                <TableHead>K</TableHead>
                <TableHead>m_pred (meV)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {neutrinos.map((n) => (
                <TableRow key={n.name}>
                  <TableCell className="font-medium">{n.name}</TableCell>
                  <TableCell>{n.n}</TableCell>
                  <TableCell>{n.K.toFixed(3)}</TableCell>
                  <TableCell>{n.m_pred.toFixed(2)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Σm_ν</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{sum_m_nu.toFixed(1)} meV</div>
            <div className="text-sm text-muted-foreground">Sum of neutrino masses</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Δm²₂₁</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dm2_21.toExponential(3)}</div>
            <div className="text-sm text-muted-foreground">eV² (+0.2σ vs NuFIT 6.0)</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Δm²₃₁</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{dm2_31.toExponential(3)}</div>
            <div className="text-sm text-muted-foreground">eV² (-0.32σ vs NuFIT 6.0)</div>
          </CardContent>
        </Card>
      </div>

      {/* Heat Kernel */}
      <Card className="bg-purple-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Badge className="bg-purple-600">Observation 8.4</Badge>
            Heat Kernel Mechanism
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={heatKernelData} margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="t" type="number" domain={[0.1, 2]} tickCount={10} />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="trace" stroke="#8b5cf6" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
              <div className="text-center text-sm text-gray-500 mt-2">
                Heat kernel H(t) = e^(-tL) on dessin&apos;s Cayley graph
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="bg-white p-4 rounded-lg">
                <div className="text-sm text-gray-500 mb-2">At t = 1/d₁ = 1/2:</div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-sm text-gray-500">Tr(H)</div>
                    <div className="text-xl font-mono">{HTraceAtHalf.toFixed(4)}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">|U₀|²</div>
                    <div className="text-xl font-mono">{U0_squared.toFixed(8)}</div>
                  </div>
                </div>
              </div>
              
              <div className="bg-white p-4 rounded-lg">
                <div className="text-sm text-gray-500 mb-2">Comparison with 4/13:</div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-sm text-gray-500">|U₀|²</div>
                    <div className="text-lg font-mono">{U0_squared.toFixed(8)}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">4/13</div>
                    <div className="text-lg font-mono">{target.toFixed(8)}</div>
                  </div>
                </div>
                <div className="mt-2 text-center">
                  <Badge className="bg-green-500">Deviation: {ppmDiff.toFixed(1)} ppm ✓</Badge>
                </div>
              </div>
              
              <div className="text-sm text-gray-600">
                The equivalence {'{double-transversal triples}'} = {'{|U₀|² ≈ 4/13}'} is a theorem. 
                This value is identical for all 4 double-transversal triples and all 36 dessins.
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Normal Ordering */}
      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
        <div className="flex items-center gap-2">
          <span className="text-green-600 text-xl">✓</span>
          <span className="font-medium">Normal ordering required: m₁ &lt; m₂ &lt; m₃</span>
        </div>
        <p className="text-sm text-gray-600 mt-2">
          Exhaustive search over 1.7×10⁶ combinations yields exactly one solution compatible with 
          NuFIT 6.0 within 3σ: the LD assignment.
        </p>
      </div>
    </div>
  );
}
