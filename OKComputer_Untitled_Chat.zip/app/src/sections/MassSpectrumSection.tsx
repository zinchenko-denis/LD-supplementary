import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { 
  particlesWithDeltaK, 
  nonAnchorParticles, 
  rms, 
  maxDeltaK,
  g
} from '@/data/modelData';
import { 
  ScatterChart, 
  Scatter, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell,
  Legend,
  ReferenceLine
} from 'recharts';

export function MassSpectrumSection() {
  const scatterData = particlesWithDeltaK.map(p => ({
    name: p.name,
    n: p.n,
    m_exp: Math.log10(p.m_exp),
    m_pred: Math.log10(p.m_pred),
    anchor: p.anchor,
    type: p.type
  }));

  const deltaKData = nonAnchorParticles.map(p => ({
    name: p.name,
    deltaK: p.deltaK,
    color: Math.abs(p.deltaK || 0) < 2 ? '#22c55e' : Math.abs(p.deltaK || 0) < 4 ? '#f97316' : '#ef4444'
  }));

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'quark': return '#3b82f6';
      case 'lepton': return '#22c55e';
      case 'boson': return '#a855f7';
      case 'anchor': return '#6b7280';
      default: return '#6b7280';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Particle Mass Spectrum</h2>
        <Badge variant="outline">Table 1</Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Mass Spectrum (Log Scale)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="n" 
                  type="number" 
                  name="Level n" 
                  domain={[-0.5, 7.5]}
                  tickCount={9}
                  label={{ value: 'Lattice level n', position: 'bottom' }}
                />
                <YAxis 
                  dataKey="m_exp" 
                  type="number" 
                  name="log₁₀(m)" 
                  label={{ value: 'log₁₀(mass [MeV])', angle: -90, position: 'insideLeft' }}
                />
                <Tooltip 
                  cursor={{ strokeDasharray: '3 3' }}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-white p-2 border rounded shadow">
                          <p className="font-bold">{data.name}</p>
                          <p>n: {data.n}</p>
                          <p>log₁₀(m_exp): {data.m_exp.toFixed(3)}</p>
                          <p>log₁₀(m_pred): {data.m_pred.toFixed(3)}</p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Scatter 
                  name="Experiment" 
                  data={scatterData.filter(d => !d.anchor)} 
                  fill="#ef4444"
                />
                <Scatter 
                  name="Anchor" 
                  data={scatterData.filter(d => d.anchor)} 
                  fill="#3b82f6"
                  shape="star"
                />
                <Scatter 
                  name="Prediction" 
                  data={scatterData} 
                  fill="#22c55e"
                  shape="diamond"
                />
                <Legend />
              </ScatterChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Residuals δK (%)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={deltaKData} margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis label={{ value: 'δK (%)', angle: -90, position: 'insideLeft' }} />
                <Tooltip 
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="bg-white p-2 border rounded shadow">
                          <p className="font-bold">{payload[0].payload.name}</p>
                          <p>δK: {payload[0].payload.deltaK.toFixed(2)}%</p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <ReferenceLine y={0} stroke="#000" />
                <Bar dataKey="deltaK">
                  {deltaKData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Mass Formula */}
      <Card className="bg-gradient-to-r from-blue-50 to-green-50">
        <CardHeader>
          <CardTitle>Central Formula</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-2xl font-mono mb-4">
            m = mₑ · μ^(n/4) · K(n) = mₑ · gⁿ · K(n)
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-center">
            <div className="bg-white p-3 rounded-lg">
              <div className="text-sm text-gray-500">mₑ</div>
              <div className="font-medium">Electron mass</div>
            </div>
            <div className="bg-white p-3 rounded-lg">
              <div className="text-sm text-gray-500">g = μ^(1/4)</div>
              <div className="font-medium text-blue-600">≈ {g.toFixed(4)}</div>
            </div>
            <div className="bg-white p-3 rounded-lg">
              <div className="text-sm text-gray-500">n</div>
              <div className="font-medium">Lattice level</div>
            </div>
            <div className="bg-white p-3 rounded-lg">
              <div className="text-sm text-gray-500">K(n) ∈ B₁</div>
              <div className="font-medium">Multiplier</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Mass Table */}
      <Card>
        <CardHeader>
          <CardTitle>Particle Assignments</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Particle</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>n</TableHead>
                <TableHead>K</TableHead>
                <TableHead>m_pred (MeV)</TableHead>
                <TableHead>m_exp (MeV)</TableHead>
                <TableHead>δK (%)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {particlesWithDeltaK.map((p) => (
                <TableRow key={p.name}>
                  <TableCell className="font-medium">{p.name}</TableCell>
                  <TableCell>
                    <span 
                      className="px-2 py-1 rounded text-xs text-white"
                      style={{ backgroundColor: getTypeColor(p.type) }}
                    >
                      {p.type}
                    </span>
                  </TableCell>
                  <TableCell>{p.n}</TableCell>
                  <TableCell>{typeof p.K === 'number' && p.K < 1 ? p.K.toFixed(3) : p.K.toFixed(2)}</TableCell>
                  <TableCell>{p.m_pred < 1000 ? p.m_pred.toFixed(2) : p.m_pred.toFixed(1)}</TableCell>
                  <TableCell>{p.m_exp < 1000 ? p.m_exp.toFixed(2) : p.m_exp.toFixed(1)}</TableCell>
                  <TableCell className={Math.abs(p.deltaK || 0) < 2 ? 'text-green-600' : Math.abs(p.deltaK || 0) < 4 ? 'text-orange-500' : 'text-red-500'}>
                    {p.anchor ? '-' : `${(p.deltaK || 0).toFixed(2)}%`}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">RMS Deviation</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{rms.toFixed(2)}%</div>
            <div className="text-sm text-muted-foreground">For 10 non-anchor particles</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Max Deviation</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-orange-500">{maxDeltaK.toFixed(2)}%</div>
            <div className="text-sm text-muted-foreground">Particle τ (tau)</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Mass Range</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">5.5</div>
            <div className="text-sm text-muted-foreground">Orders of magnitude</div>
          </CardContent>
        </Card>
      </div>

      {/* Quark Sub-ladder */}
      <Card className="bg-amber-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Badge className="bg-amber-500">§2.5</Badge>
            Quark Sub-ladder
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center mb-4">
            <div className="text-lg font-mono">m_s/m_u = m_t/m_b = μ^(1/2) ≈ 42.8</div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white p-3 rounded-lg text-center">
              <div className="text-sm text-gray-500">Experimental</div>
              <div className="font-medium">m_s/m_u = 43.2</div>
            </div>
            <div className="bg-white p-3 rounded-lg text-center">
              <div className="text-sm text-gray-500">Experimental</div>
              <div className="font-medium">m_t/m_b = 41.3</div>
            </div>
          </div>
          <p className="text-sm text-gray-600 mt-3 text-center">
            Four quarks (u, s, b, t) share K = 2/3 with equal spacing Δn = 2
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
