import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { deltaKTable, signsMatch, alpha_2pi } from '@/data/modelData';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  ReferenceLine,
  Cell
} from 'recharts';

export function DeltaKSection() {
  const [n, setN] = useState(4);
  const [ell, setEll] = useState(3);
  const [phiExponent, setPhiExponent] = useState(3);
  
  const N = 6;
  const phi = n ** phiExponent * (1 - n / (N + 1));
  const deltaK_pred = (alpha_2pi) * (phi - (N + 1) * ell) * 100;

  const chartData = deltaKTable.map(d => ({
    name: d.name,
    pred: d.pred,
    obs: d.obs,
    signMatch: Math.sign(d.pred) === Math.sign(d.obs)
  }));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">The δK Formula</h2>
        <Badge variant="outline">§6</Badge>
      </div>

      {/* Formula */}
      <Card className="bg-gradient-to-r from-purple-50 to-blue-50">
        <CardHeader>
          <CardTitle>Unified Formula (Eq. 7)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-2xl font-mono mb-4">
            δK/K = (α/2π) [Φ(n) - (N+1)ℓ]
          </div>
          <div className="text-center text-lg text-gray-600">
            where ℓ = -2(T₃ - d₂|Q|)
          </div>
          <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white p-3 rounded text-center">
              <div className="text-sm text-gray-500">Φ(n)</div>
              <div className="font-mono">n³(1 - n/7)</div>
            </div>
            <div className="bg-white p-3 rounded text-center">
              <div className="text-sm text-gray-500">N+1</div>
              <div className="font-mono">= 7</div>
            </div>
            <div className="bg-white p-3 rounded text-center">
              <div className="text-sm text-gray-500">d₂</div>
              <div className="font-mono">= 3</div>
            </div>
            <div className="bg-white p-3 rounded text-center">
              <div className="text-sm text-gray-500">α/(2π)</div>
              <div className="font-mono">{alpha_2pi.toExponential(3)}</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Interactive Calculator */}
      <Card>
        <CardHeader>
          <CardTitle>Interactive δK Calculator</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Lattice level n: {n}</span>
              </div>
              <Slider value={[n]} onValueChange={([v]) => setN(v)} min={0} max={7} step={1} />
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>EW operator ℓ: {ell}</span>
              </div>
              <Slider value={[ell]} onValueChange={([v]) => setEll(v)} min={1} max={7} step={1} />
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Φ exponent k: {phiExponent}</span>
                <Badge className="bg-green-500">Sign Window: k=3</Badge>
              </div>
              <Slider value={[phiExponent]} onValueChange={([v]) => setPhiExponent(v)} min={1} max={5} step={0.1} />
            </div>

            <div className="bg-slate-50 p-4 rounded-lg">
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-sm text-gray-500">Φ(n)</div>
                  <div className="text-xl font-mono">{phi.toFixed(2)}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-500">(N+1)ℓ</div>
                  <div className="text-xl font-mono">{(N+1) * ell}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-500">Predicted δK</div>
                  <div className={`text-xl font-bold ${deltaK_pred > 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {deltaK_pred > 0 ? '+' : ''}{deltaK_pred.toFixed(2)}%
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Sign Window Theorem */}
      <Card className="bg-green-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Badge className="bg-green-600">Theorem 6.1</Badge>
            Sign Window Theorem
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center mb-4">
            <p className="text-lg">k = d₂ = 3 is the unique integer giving 10/10 correct signs</p>
          </div>
          <div className="flex items-center justify-center gap-4">
            <div className="text-center p-3 bg-white rounded-lg">
              <div className="text-sm text-gray-500">Window</div>
              <div className="font-mono">(2.807, 3.172)</div>
            </div>
            <div className="text-center p-3 bg-white rounded-lg">
              <div className="text-sm text-gray-500">Width</div>
              <div className="font-mono">0.365</div>
            </div>
            <div className="text-center p-3 bg-green-100 rounded-lg">
              <div className="text-sm text-gray-500">Sign matches</div>
              <div className="font-bold text-green-600">10/10 ✓</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Predicted δK</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={chartData} margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis domain={[-6, 4]} label={{ value: 'δK (%)', angle: -90, position: 'insideLeft' }} />
                <Tooltip />
                <ReferenceLine y={0} stroke="#000" />
                <Bar dataKey="pred">
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.pred > 0 ? '#22c55e' : '#ef4444'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Observed δK</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={chartData} margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis domain={[-6, 4]} label={{ value: 'δK (%)', angle: -90, position: 'insideLeft' }} />
                <Tooltip />
                <ReferenceLine y={0} stroke="#000" />
                <Bar dataKey="obs">
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.obs > 0 ? '#22c55e' : '#ef4444'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Table */}
      <Card>
        <CardHeader>
          <CardTitle>Table 2: Predictions vs Observations</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Particle</TableHead>
                <TableHead>n</TableHead>
                <TableHead>ℓ</TableHead>
                <TableHead>Φ(n)</TableHead>
                <TableHead>EW</TableHead>
                <TableHead>δK_pred (%)</TableHead>
                <TableHead>δK_obs (%)</TableHead>
                <TableHead>Sign</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {deltaKTable.map((d) => {
                const signMatch = Math.sign(d.pred) === Math.sign(d.obs);
                return (
                  <TableRow key={d.name}>
                    <TableCell className="font-medium">{d.name}</TableCell>
                    <TableCell>{d.n}</TableCell>
                    <TableCell>{d.ell}</TableCell>
                    <TableCell>{d.phi.toFixed(2)}</TableCell>
                    <TableCell>{d.ew.toFixed(1)}</TableCell>
                    <TableCell className={d.pred > 0 ? 'text-green-600' : 'text-red-500'}>
                      {d.pred > 0 ? '+' : ''}{d.pred.toFixed(2)}
                    </TableCell>
                    <TableCell className={d.obs > 0 ? 'text-green-600' : 'text-red-500'}>
                      {d.obs > 0 ? '+' : ''}{d.obs.toFixed(2)}
                    </TableCell>
                    <TableCell>
                      {signMatch ? (
                        <span className="text-green-600 font-bold">✓</span>
                      ) : (
                        <span className="text-red-500 font-bold">✗</span>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
          <div className="mt-4 p-3 bg-green-50 rounded-lg text-center">
            <span className="font-medium">Sign matches: {signsMatch}/10</span>
            <span className="text-gray-500 ml-2">| RMS = 1.45% | Zero continuous adjustable parameters</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
