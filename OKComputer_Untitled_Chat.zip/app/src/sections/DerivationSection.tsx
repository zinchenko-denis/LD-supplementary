import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { derivationStatus } from '@/data/modelData';

export function DerivationSection() {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'theorem':
        return <Badge className="bg-green-600">[THM]</Badge>;
      case 'derived':
        return <Badge className="bg-blue-600">[DER]</Badge>;
      case 'observational':
        return <Badge className="bg-yellow-600">[OBS]</Badge>;
      case 'conjecture':
        return <Badge className="bg-purple-600">[CONJ]</Badge>;
      case 'fitted':
        return <Badge className="bg-orange-600">[FIT]</Badge>;
      case 'gap':
        return <Badge className="bg-red-600">[GAP]</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const grouped = {
    theorem: derivationStatus.filter(d => d.status === 'theorem'),
    derived: derivationStatus.filter(d => d.status === 'derived'),
    observational: derivationStatus.filter(d => d.status === 'observational'),
    conjecture: derivationStatus.filter(d => d.status === 'conjecture'),
    fitted: derivationStatus.filter(d => d.status === 'fitted'),
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Derivation Status</h2>
        <Badge variant="outline">§10.3</Badge>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <Card className="bg-green-50">
          <CardContent className="p-4 text-center">
            <div className="text-3xl font-bold text-green-600">{grouped.theorem.length}</div>
            <div className="text-sm text-gray-500">[THM] Theorems</div>
          </CardContent>
        </Card>
        <Card className="bg-blue-50">
          <CardContent className="p-4 text-center">
            <div className="text-3xl font-bold text-blue-600">{grouped.derived.length}</div>
            <div className="text-sm text-gray-500">[DER] Derived</div>
          </CardContent>
        </Card>
        <Card className="bg-yellow-50">
          <CardContent className="p-4 text-center">
            <div className="text-3xl font-bold text-yellow-600">{grouped.observational.length}</div>
            <div className="text-sm text-gray-500">[OBS] Observational</div>
          </CardContent>
        </Card>
        <Card className="bg-purple-50">
          <CardContent className="p-4 text-center">
            <div className="text-3xl font-bold text-purple-600">{grouped.conjecture.length}</div>
            <div className="text-sm text-gray-500">[CONJ] Conjecture</div>
          </CardContent>
        </Card>
        <Card className="bg-orange-50">
          <CardContent className="p-4 text-center">
            <div className="text-3xl font-bold text-orange-600">{grouped.fitted.length}</div>
            <div className="text-sm text-gray-500">[FIT] Fitted</div>
          </CardContent>
        </Card>
      </div>

      {/* Legend */}
      <Card>
        <CardHeader>
          <CardTitle>Status Legend</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
            <div className="flex items-center gap-2">
              <Badge className="bg-green-600">[THM]</Badge>
              <span>Mathematically proven</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge className="bg-blue-600">[DER]</Badge>
              <span>Derived from framework</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge className="bg-yellow-600">[OBS]</Badge>
              <span>Observational identification</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge className="bg-purple-600">[CONJ]</Badge>
              <span>Conjectured</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge className="bg-orange-600">[FIT]</Badge>
              <span>Fitted to data</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge className="bg-red-600">[GAP]</Badge>
              <span>Open question</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Full Table */}
      <Card>
        <CardHeader>
          <CardTitle>Complete Derivation Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50">
                <tr>
                  <th className="p-2 text-left">Result</th>
                  <th className="p-2 text-left">Status</th>
                  <th className="p-2 text-left">Reference</th>
                </tr>
              </thead>
              <tbody>
                {derivationStatus.map((d, i) => (
                  <tr key={i} className="border-b hover:bg-slate-50">
                    <td className="p-2">{d.result}</td>
                    <td className="p-2">{getStatusBadge(d.status)}</td>
                    <td className="p-2 text-gray-500">{d.reference}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Gap 3 */}
      <Card className="bg-red-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Badge className="bg-red-600">Gap 3</Badge>
            What Remains Open
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">
            Each ingredient of the δK formula is traced to Γ₀(6):
          </p>
          <ul className="list-disc list-inside space-y-1 text-sm mb-4">
            <li>Exponents (d₂, d₁-1) from ramification</li>
            <li>Boundary L = N+1 from well-posedness</li>
            <li>Coupling α/(2π) from 4D Weyl</li>
            <li>ℓ from the dessin</li>
            <li>n from eccentricity</li>
          </ul>
          <div className="p-4 bg-white rounded-lg text-center">
            <p className="font-medium text-lg">
              The sole remaining question: <span className="text-red-600">why is the overall coupling α/(2π)?</span>
            </p>
          </div>
          <p className="mt-4 text-sm text-gray-600 text-center">
            This is the Balmer → Schrödinger gap.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
