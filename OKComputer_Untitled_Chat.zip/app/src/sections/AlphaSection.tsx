import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { alphaFormula, CONSTANTS } from '@/data/modelData';

export function AlphaSection() {
  const predictedAlphaInv = alphaFormula.bulk + alphaFormula.ir;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Fine Structure Constant α</h2>
        <Badge variant="outline">§5</Badge>
      </div>

      {/* Formula */}
      <Card className="bg-gradient-to-r from-purple-50 to-pink-50">
        <CardHeader>
          <CardTitle>α⁻¹ Formula (Eq. 6)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-xl font-mono mb-6">
            α⁻¹ = (index · Πwᵢ / π) · cos²(1/Nπ) - π/(Πwᵢ) · (1 - 1/j(i) + dimM₁₀/j(i)²)
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-4 rounded-lg">
              <div className="text-center mb-3">
                <Badge className="bg-blue-500 mb-2">BULK term (~600 ppm)</Badge>
              </div>
              <div className="text-center font-mono text-lg">
                (432/π) · cos²(1/6π)
              </div>
              <div className="text-center text-2xl font-bold text-blue-600 mt-2">
                = {alphaFormula.bulk.toFixed(4)}
              </div>
              <div className="text-center text-xs text-gray-500 mt-1">
                Derived from Γ₀(6) invariants (§5.5)
              </div>
            </div>
            
            <div className="bg-white p-4 rounded-lg">
              <div className="text-center mb-3">
                <Badge className="bg-orange-500 mb-2">IR correction (0.001 ppb)</Badge>
              </div>
              <div className="text-center font-mono text-lg">
                (π/36) · (1 - 1/1728 + 11/1728²)
              </div>
              <div className="text-center text-2xl font-bold text-orange-600 mt-2">
                = {alphaFormula.ir.toFixed(4)}
              </div>
              <div className="text-center text-xs text-gray-500 mt-1">
                Fitted, with structural coefficients (Remark 5.2)
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Predicted α⁻¹</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600">{predictedAlphaInv.toFixed(6)}</div>
            <div className="text-sm text-muted-foreground">BULK + IR</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Experimental (CODATA)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">{CONSTANTS.alpha_inv.toFixed(6)}</div>
            <div className="text-sm text-muted-foreground">2018</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Residual</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-purple-600">0.001 ppb</div>
            <div className="text-sm text-muted-foreground">vs CODATA</div>
          </CardContent>
        </Card>
      </div>

      {/* Components */}
      <Card>
        <CardHeader>
          <CardTitle>Formula Components</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-3 bg-slate-50 rounded-lg">
              <div className="text-sm text-gray-500">index</div>
              <div className="text-xl font-bold">12</div>
              <div className="text-xs text-gray-400">[Γ:Γ₀(6)]</div>
            </div>
            <div className="text-center p-3 bg-slate-50 rounded-lg">
              <div className="text-sm text-gray-500">Πwᵢ</div>
              <div className="text-xl font-bold">36</div>
              <div className="text-xs text-gray-400">Product of cusp widths</div>
            </div>
            <div className="text-center p-3 bg-slate-50 rounded-lg">
              <div className="text-sm text-gray-500">j(i)</div>
              <div className="text-xl font-bold">1728</div>
              <div className="text-xs text-gray-400">Elliptic value</div>
            </div>
            <div className="text-center p-3 bg-slate-50 rounded-lg">
              <div className="text-sm text-gray-500">dimM₁₀</div>
              <div className="text-xl font-bold">11</div>
              <div className="text-xs text-gray-400">From c₂ = 11</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Self-consistent Loop */}
      <Card className="bg-gradient-to-r from-green-50 to-blue-50">
        <CardHeader>
          <CardTitle>Self-Consistent Loop (§5.6)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center flex-wrap gap-2 text-lg font-mono">
            <span className="px-3 py-2 bg-white rounded-lg">HF</span>
            <span>→</span>
            <span className="px-3 py-2 bg-blue-100 rounded-lg">α</span>
            <span>→</span>
            <span className="px-3 py-2 bg-green-100 rounded-lg">μ</span>
            <span>→</span>
            <span className="px-3 py-2 bg-purple-100 rounded-lg">masses</span>
            <span>→</span>
            <span className="px-3 py-2 bg-orange-100 rounded-lg">F_G</span>
            <span>→</span>
            <span className="px-3 py-2 bg-blue-100 rounded-lg">α</span>
          </div>
          <div className="mt-4 text-center text-sm text-gray-600">
            With anchors (e+p): 3 iterations, 1/α = 137.0359662 (0.24 ppm)
          </div>
          <div className="mt-2 text-center">
            <Badge className="bg-green-500">α is a fixed point, not an eigenvalue</Badge>
          </div>
        </CardContent>
      </Card>

      {/* Rb-Cs Tension */}
      <Card className="bg-yellow-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Badge className="bg-yellow-600">Falsifiable</Badge>
            Rb-Cs Tension
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm mb-4">
            The α-formula selects CODATA via c₂ = dimM₁₀ = 11. Extracting c₂ from each α determination:
          </p>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center p-3 bg-green-100 rounded-lg">
              <div className="font-bold">CODATA</div>
              <div className="text-2xl font-mono">11.006</div>
              <div className="text-xs text-green-600">✓ Matches</div>
            </div>
            <div className="text-center p-3 bg-red-100 rounded-lg">
              <div className="font-bold">Rb</div>
              <div className="text-2xl font-mono">6.831</div>
              <div className="text-xs text-red-600">✗ No match</div>
            </div>
            <div className="text-center p-3 bg-red-100 rounded-lg">
              <div className="font-bold">Cs</div>
              <div className="text-2xl font-mono">12.306</div>
              <div className="text-xs text-red-600">✗ No match</div>
            </div>
          </div>
          <p className="text-sm mt-4 text-center">
            Resolution of the Rb-Cs 5.4σ tension towards Rb would falsify the formula.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
